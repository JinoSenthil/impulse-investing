'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useSelector } from 'react-redux';
import { RootState } from '@/lib/store';
import Link from 'next/link';
import ApiService from '@/services/ApiService';
import { OnlineCourseDetails, CourseModule, CourseLesson } from '@/types';
import { ArrowLeft, BookOpen, Clock, ChevronRight, CheckCircle, Lock, PlayCircle, AlertCircle, X } from 'lucide-react';
import Image from 'next/image';

// Use the imported types instead of redefining them
import type { CourseTest as ImportedCourseTest, TestQuestion as ImportedTestQuestion, UserTest as ImportedUserTest } from '@/types';

// Extend the imported types to match your page's requirements
interface TestQuestion extends Omit<ImportedTestQuestion, 'correctOption'> {
  correctOption: string;
}

interface CourseTest extends Omit<ImportedCourseTest, 'questions'> {
  questions: TestQuestion[];
}

interface UserTest extends Omit<ImportedUserTest, 'testAnswer'> {
  testAnswer: Array<{
    id: number;
    questionId: number;
    selectedOption: string;
    isCorrect: boolean;
  }>;
}

export default function LevelPage() {
  const params = useParams();
  const router = useRouter();
  const { user } = useSelector((state: RootState) => state.auth);
  const userId = user?.id;

  const courseNumber = params.courseNumber as string;
  const levelId = params.levelId as string;

  const [courseData, setCourseData] = useState<OnlineCourseDetails | null>(null);
  const [currentModule, setCurrentModule] = useState<CourseModule | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<CourseLesson | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isReviewMode, setIsReviewMode] = useState(false);

  // Quiz State
  const [activeTab, setActiveTab] = useState<'study' | 'quiz'>('study');
  const [currentTest, setCurrentTest] = useState<CourseTest | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: number }>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [, setIsPassed] = useState(false);
  const [score, setScore] = useState(0);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [showResultAlert, setShowResultAlert] = useState(false);
  const [userTests, setUserTests] = useState<UserTest[]>([]);

  // Track completed lessons
  const [completedLessons, setCompletedLessons] = useState<Set<number>>(new Set());
  // Track visited lessons to auto-mark as complete
  const [visitedLessons, setVisitedLessons] = useState<Set<number>>(new Set());

  // Track next module availability
  const [hasNextModule, setHasNextModule] = useState(false);
  const [nextModuleId, setNextModuleId] = useState<number | null>(null);

  // New state for quiz navigation
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [quizStarted, setQuizStarted] = useState(false);

  useEffect(() => {
    // Check if we're in review mode from query parameters
    const searchParams = new URLSearchParams(window.location.search);
    const reviewParam = searchParams.get('review');
    setIsReviewMode(reviewParam === 'true');
  }, []);

  // Add browser back button handling
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      if (activeTab === 'quiz' && quizStarted && !quizSubmitted) {
        setShowExitConfirm(true);
        // Prevent the actual navigation
        window.history.pushState(null, '', window.location.href);
      }
    };

    window.addEventListener('popstate', handlePopState);
    
    // Initialize history state
    window.history.pushState(null, '', window.location.href);

    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [activeTab, quizStarted, quizSubmitted]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await ApiService.getOnlineCourseDetails(courseNumber);
        setCourseData(data);

        const moduleIdNum = parseInt(levelId.replace('level-', ''));
        const foundModule = data.onlineCourse[0]?.modules?.find(m => m.id === moduleIdNum);

        // Check if there's a next module
        if (foundModule && data.onlineCourse[0]?.modules) {
          const moduleIndex = data.onlineCourse[0].modules.findIndex(m => m.id === moduleIdNum);
          if (moduleIndex !== -1 && moduleIndex < data.onlineCourse[0].modules.length - 1) {
            const nextMod = data.onlineCourse[0].modules[moduleIndex + 1];
            setHasNextModule(true);
            setNextModuleId(nextMod.id);
          }
        }

        // Type-safe test handling
        const testData = data.test?.find(t => t.moduleId === moduleIdNum);
        if (testData) {
          // Cast the test data to match our extended type
          const typedTest: CourseTest = {
            ...testData,
            questions: testData.questions.map(q => ({
              ...q,
              correctOption: q.correctOption ?? ''
            }))

          };
          setCurrentTest(typedTest);
          setTotalQuestions(typedTest.questions.length);
        }

        if (foundModule) {
          setCurrentModule(foundModule);
          // Set first lesson as default
          if (foundModule.lessons && foundModule.lessons.length > 0) {
            const firstLesson = foundModule.lessons[0];
            setSelectedLesson(firstLesson);
            // Auto-mark first lesson as visited
            setVisitedLessons(prev => new Set([...prev, firstLesson.id]));
          }
        } else {
          setError('Module not found');
        }

        // Fetch user test history
        if (userId && moduleIdNum) {
          try {
            const tests = await ApiService.getAllUserTests({
              userId,
              moduleId: moduleIdNum
            });

            // Type-safe conversion
            const typedTests: UserTest[] = Array.isArray(tests)
              ? tests.map(test => ({
                ...test,
                testAnswer: Array.isArray(test.testAnswer) ? test.testAnswer : []
              }))
              : [];


            setUserTests(typedTests);
            console.log('User tests loaded:', typedTests);
            
            // If in review mode, automatically switch to study tab
            if (isReviewMode || typedTests.length > 0) {
              setActiveTab('study');
            }
          } catch (error) {
            console.error('Failed to fetch user tests:', error);
          }
        }
      } catch (err) {
        console.error('Failed to fetch course details:', err);
        setError('Failed to load lesson. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    if (courseNumber && levelId) {
      fetchData();
    }
  }, [courseNumber, levelId, userId, isReviewMode]);

  // Auto-mark lesson as completed when selected
  useEffect(() => {
    if (selectedLesson) {
      // Mark as visited
      setVisitedLessons(prev => new Set([...prev, selectedLesson.id]));

      // Auto-complete after a short delay (simulating user viewing the lesson)
      const timer = setTimeout(() => {
        setCompletedLessons(prev => {
          const newSet = new Set([...prev, selectedLesson.id]);
          return newSet;
        });
      }, 100); 

      return () => clearTimeout(timer);
    }
  }, [selectedLesson]);

  // Reset quiz started state when switching tabs
  useEffect(() => {
    if (activeTab === 'study') {
      setQuizStarted(false);
    }
  }, [activeTab]);

  // Check if all lessons are completed
  const allLessonsCompleted = currentModule?.lessons
    ? completedLessons.size === currentModule.lessons.length
    : false;

  const handleOptionSelect = (questionId: number, optionIndex: number) => {
    if (quizSubmitted || !currentTest) return;
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex // This should be 1, 2, 3, or 4
    }));
  };

  const handleNextQuestion = () => {
    if (currentTest && currentQuestionIndex < currentTest.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const handleTakeQuizChallenge = () => {
    // If in review mode, don't allow taking quiz
    if (isReviewMode) {
      alert('You have already completed this quiz. You can only review the study material.');
      return;
    }
    
    const hasPassed = Array.isArray(userTests) && userTests.some(test => test.isPassed);

    if (hasPassed) {
      if (window.confirm('You have already passed this quiz. Do you want to retake it?')) {
        setActiveTab('quiz');
        resetQuiz();
      }
    } else {
      setActiveTab('quiz');
      resetQuiz();
    }
  };

  const calculateScore = async () => {
    if (!currentTest || !userId || !currentModule) {
      console.error('No test available or user not authenticated');
      alert('Please log in to submit your test results.');
      return;
    }

    // First, calculate the score locally
    let correctAnswers = 0;
    const answerDetails = currentTest.questions.map(question => {
      const selectedOption = selectedAnswers[question.id];
      let isCorrect = false;

      if (selectedOption !== undefined) {
        // Convert "OPTION1" to 1, "OPTION2" to 2, etc.
        const correctOptionNumber = parseInt(question.correctOption.replace('OPTION', ''));
        isCorrect = (selectedOption === correctOptionNumber);

        if (isCorrect) {
          correctAnswers++;
        }
      }

      return {
        questionId: question.id,
        selectedOption: selectedOption !== undefined ? `OPTION${selectedOption}` : '',
        isCorrect: isCorrect
      };
    });

    const totalQuestions = currentTest.questions.length;

    // Calculate based on passMark as number of correct answers needed
    const passMark = currentTest.passMark || Math.ceil(totalQuestions * 0.6); // 60% as default
    const passed = correctAnswers >= passMark;

    console.log('Local Quiz Calculation:', {
      correctAnswers,
      totalQuestions,
      passMark,
      passed,
      percentage: (correctAnswers / totalQuestions) * 100
    });

    try {
      // Prepare submission data
      const submissionData = {
        userId: userId,
        testId: currentTest.id,
        moduleId: currentModule.id,
        answers: answerDetails.map(answer => ({
          questionId: answer.questionId,
          selectedOption: answer.selectedOption
        }))
      };

      // Submit to API
      const response = await ApiService.createUserTest(submissionData);
      console.log('API Response:', response);

      // IMPORTANT: Use our local calculation for pass/fail, not the API's
      // The backend API is returning incorrect isPassed value
      const finalScore = response.score || correctAnswers;
      const finalTotalQuestions = response.testAnswer?.length || totalQuestions;

      // ALWAYS use our local calculation for pass/fail
      const finalIsPassed = passed; // This is our correct calculation

      // But also check if the API gave us a score that we should use
      let apiScore = finalScore;


      if (Array.isArray(response.testAnswer)) {
        const apiCorrectAnswers = response.testAnswer.filter(answer => {
          return (
            typeof answer === 'object' &&
            answer !== null &&
            'isCorrect' in answer &&
            Boolean((answer as { isCorrect?: boolean }).isCorrect)
          );
        }).length;

        apiScore = apiCorrectAnswers;
      }


      console.log('Final Results to Show:', {
        score: apiScore,
        isPassed: finalIsPassed,
        totalQuestions: finalTotalQuestions,
        localCalculation: {
          correctAnswers,
          passed,
          passMark
        }
      });

      // Set the state with our corrected values
      setScore(apiScore);
      setIsPassed(finalIsPassed);
      setTotalQuestions(finalTotalQuestions);
      setQuizSubmitted(true);
      setShowResultAlert(true);
      setQuizStarted(false);

      // Refresh user tests
      if (currentModule.id) {
        const tests = await ApiService.getAllUserTests({
          userId,
          moduleId: currentModule.id
        });

        // Type-safe conversion
        const typedTests: UserTest[] = Array.isArray(tests)
          ? tests.map(test => ({
            ...test,
            testAnswer: Array.isArray(test.testAnswer) ? test.testAnswer : []
          }))
          : [];


        setUserTests(typedTests);
      }
    } catch (error) {
      console.error('Failed to submit test:', error);
      // Use local calculation as fallback
      setScore(correctAnswers);
      setIsPassed(passed);
      setTotalQuestions(totalQuestions);
      setQuizSubmitted(true);
      setShowResultAlert(true);
      setQuizStarted(false);
    }
  };

  const resetQuiz = () => {
    setShowResultAlert(false);
    setQuizSubmitted(false);
    setCurrentQuestionIndex(0);
    setSelectedAnswers({});
    setScore(0);
    setIsPassed(false);
    setQuizStarted(true);
  };

  const handleBackToLessons = () => {
    setShowResultAlert(false);
    router.push(`/premium-courses/${courseNumber}`);
  };

  const handleStartNextLesson = () => {
    if (hasNextModule && nextModuleId) {
      // Navigate to next module
      router.push(`/premium-courses/${courseNumber}/level-${nextModuleId}`);
    } else {
      // No next module, go back to course page or show completion
      router.push(`/premium-courses/${courseNumber}?completed=true`);
    }
    setShowResultAlert(false);
  };

  const handleRetakeQuiz = () => {
    resetQuiz();
    setShowResultAlert(false);
  };

  const handleBackClick = () => {
    if (activeTab === 'quiz' && quizStarted && !quizSubmitted) {
      setShowExitConfirm(true);
    } else {
      router.push(`/premium-courses/${courseNumber}`);
    }
  };

  const confirmExitQuiz = () => {
    setShowExitConfirm(false);
    setQuizStarted(false);
    // Use a small timeout to ensure state updates before navigation
    setTimeout(() => {
      router.push(`/premium-courses/${courseNumber}`);
    }, 10);
  };

  const cancelExitQuiz = () => {
    setShowExitConfirm(false);
    // Ensure we have a history state to prevent immediate back navigation
    window.history.pushState(null, '', window.location.href);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#020C0E] flex items-center justify-center">
        <div className="text-green-500 font-cinzel text-2xl animate-pulse">Loading Lessons...</div>
      </div>
    );
  }

  if (error || !currentModule || !courseData) {
    return (
      <div className="min-h-screen bg-[#020C0E] flex flex-col items-center justify-center text-white gap-4">
        <h1 className="text-2xl font-bold text-red-500">{error || 'Module Not Found'}</h1>
        <Link href={`/premium-courses/${courseNumber}`} className="text-green-400 hover:underline">
          Return to Course
        </Link>
      </div>
    );
  }

  const course = courseData.onlineCourse[0];
  const moduleIndex = course.modules?.findIndex(m => m.id === currentModule.id) ?? 0;
  const levelNumber = moduleIndex + 1;

  return (
    <div className="min-h-screen bg-[#020C0E] text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#05161A]/95 backdrop-blur-xl border-b border-green-500/10 px-6 py-4 shadow-2xl">
        <div className="w-[90%] max-w-[1800px] mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={handleBackClick}
              className="flex items-center gap-2 text-text-secondary hover:text-green-400 transition-colors font-semibold group"
            >
              <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              <span className="hidden sm:inline">Back</span>
            </button>

            {/* Mode Toggles */}
            <div className="flex bg-[#0A2228] rounded-lg p-1 border border-green-500/20">
              <button
                onClick={() => activeTab === 'quiz' && quizStarted ? null : setActiveTab('study')}
                className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-bold transition-all ${activeTab === 'study'
                  ? 'bg-green-500 text-black shadow-lg'
                  : 'text-gray-400 hover:text-white'
                  } ${activeTab === 'quiz' && quizStarted ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'
                  }`}
                disabled={activeTab === 'quiz' && quizStarted}
              >
                <BookOpen className="w-4 h-4" />
                Study Material
              </button>
              {currentTest && !isReviewMode && (
                <button
                  onClick={() => {
                    if (allLessonsCompleted && currentTest) {
                      handleTakeQuizChallenge();
                    }
                  }}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-bold transition-all
    ${activeTab === 'quiz'
                      ? 'bg-accent-gold text-black shadow-lg'
                      : 'text-gray-400 hover:text-white'
                    }
    ${!allLessonsCompleted || (activeTab === 'quiz' && quizStarted)
                      ? 'cursor-not-allowed opacity-50'
                      : 'cursor-pointer'
                    }
  `}
                  disabled={!allLessonsCompleted || (activeTab === 'quiz' && quizStarted)}

                >
                  <span className="w-4 h-4 flex items-center justify-center border border-current rounded-full text-[10px] font-black">?</span>
                  Quiz Challenge
                </button>
              )}
            </div>
          </div>

          <div className="text-center hidden md:block">
            <h1 className="font-cinzel text-lg font-bold tracking-[2px] text-green-500">
              Level {levelNumber}: {currentModule.title}
            </h1>
          </div>


        </div>
      </header>

      {activeTab === 'study' ? (
        <div className="flex min-h-[calc(100vh-73px)]">
          {/* Fixed Sidebar - Lessons List */}
          <aside className="hidden lg:block w-80 bg-[#05161A] border-r border-green-500/10 flex-shrink-0 sticky top-[73px] h-[calc(100vh-73px)]">
            <div className="h-full flex flex-col">
              {/* Fixed Header */}
              <div className="p-6 border-b border-green-500/10 flex-shrink-0">
                <h2 className="text-xl font-bold mb-2">Course Lessons</h2>
                <p className="text-sm text-gray-400">
                  {completedLessons.size} of {currentModule.lessons?.length || 0} lessons completed
                </p>
              
                {isReviewMode && (
                  <div className="mt-2 text-sm text-green-400 bg-green-500/10 px-2 py-1 rounded">
                    ✓ Quiz Completed
                  </div>
                )}
              </div>

              {/* Scrollable Lessons Area */}
              <div className="flex-1 overflow-y-auto p-6 pt-4 custom-scrollbar">
                <div className="space-y-3">
                  {currentModule.lessons?.map((lesson, index) => {
                    const isCompleted = completedLessons.has(lesson.id);
                    const isVisited = visitedLessons.has(lesson.id);
                    return (
                      <button
                        key={lesson.id}
                        onClick={() => setSelectedLesson(lesson)}
                        className={`w-full text-left p-4 rounded-xl transition-all duration-300 ${selectedLesson?.id === lesson.id
                          ? 'bg-green-500/20 border-2 border-green-500 shadow-[0_0_20px_rgba(34,197,94,0.2)]'
                          : 'bg-[#0A2228] border-2 border-transparent hover:border-green-500/30 hover:bg-[#0D2D35]'
                          }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${isCompleted
                            ? 'bg-green-500 text-black'
                            : selectedLesson?.id === lesson.id
                              ? 'bg-green-500 text-black'
                              : isVisited
                                ? 'bg-green-300/20 text-green-300'
                                : 'bg-green-500/10 text-green-400'
                            }`}>
                            {isCompleted ? <CheckCircle className="w-4 h-4" /> : index + 1}
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className={`font-semibold text-sm mb-1 line-clamp-2 ${selectedLesson?.id === lesson.id ? 'text-green-400' : 'text-white'
                              }`}>
                              {lesson.title}
                            </h3>
                            {lesson.duration && lesson.duration !== '0:00' && (
                              <div className="flex items-center gap-1 text-xs text-gray-500">
                                <Clock className="w-3 h-3" />
                                <span>{lesson.duration}</span>
                              </div>
                            )}
                          </div>
                          {selectedLesson?.id === lesson.id && (
                            <ChevronRight className="w-5 h-5 text-green-400 flex-shrink-0" />
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Fixed Footer - Quiz Challenge Button */}
              <div className="p-6 pt-4 border-t border-green-500/10 flex-shrink-0">
                {currentTest && !isReviewMode && (
                  <button
                 
                    className={`w-full p-4 rounded-xl font-bold transition-all flex items-center justify-center gap-3 ${allLessonsCompleted
                      ? 'bg-[#0A2228] text-gray-400 hover:text-white hover:border-accent-gold/30 hover:border'
                      : 'bg-[#0A2228] border border-yellow-500/30 text-gray-400 cursor-not-allowed'
                      }`}
                    disabled={!allLessonsCompleted}
                  >
                    {allLessonsCompleted ? (
                      <>
                        <PlayCircle className="w-5 h-5" />
                        Attend a quiz now
                      </>
                    ) : (
                      <>
                        <Lock className="w-5 h-5" />
                        Complete all {currentModule.lessons?.length || 0} lessons to unlock quiz
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          </aside>

          {/* Main Content - Scrollable Area */}
          <main className="flex-1 overflow-y-auto">
            {selectedLesson ? (
              <div className="p-6 md:p-8 lg:p-12 max-w-4xl mx-auto">
                {/* Lesson Header */}
                <div className="mb-8">
                  <div className="flex items-center gap-2 text-green-400 text-sm font-bold mb-4">
                    <BookOpen className="w-4 h-4" />
                    <span>LESSON {currentModule.lessons?.findIndex(l => l.id === selectedLesson.id) + 1 || 1}</span>
                  </div>
                  <h1 className="text-3xl md:text-3xl font-bold mb-4 leading-tight">
                    {selectedLesson.title}
                  </h1>
                  {selectedLesson.duration && selectedLesson.duration !== '0:00' && (
                    <div className="flex items-center gap-2 text-gray-400">
                      <Clock className="w-4 h-4" />
                      <span>{selectedLesson.duration}</span>
                    </div>
                  )}
                </div>

                {/* Progress Indicator */}
                <div className="mb-8 p-4 bg-[#0A2228]/50 rounded-xl border border-green-500/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-400">Progress</span>
                    <span className="text-sm font-bold text-green-400">
                      {completedLessons.size}/{currentModule.lessons?.length || 0} lessons
                    </span>
                  </div>
                  <div className="w-full h-2 bg-[#05161A] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-green-500 transition-all duration-500"
                      style={{
                        width: currentModule.lessons?.length
                          ? `${(completedLessons.size / currentModule.lessons.length) * 100}%`
                          : '0%'
                      }}
                    />
                  </div>
                </div>

                {/* Lesson Content */}
                <div className="mb-8 prose prose-invert prose-green max-w-none">
                  <div className="bg-[#05161A] border border-green-500/10 rounded-2xl p-6 md:p-8">
                    <h2 className="text-2xl font-bold mb-6 text-green-400">Lesson Content</h2>
                    <div
                      className="text-gray-300 leading-relaxed whitespace-pre-wrap"
                      style={{ fontSize: '1.1rem', lineHeight: '1.8' }}
                    >
                      {selectedLesson.description}
                    </div>
                  </div>
                </div>

                {/* Video/Image Content */}
                {selectedLesson.url && selectedLesson.url !== '' && (
                  <div className="rounded-2xl overflow-hidden border border-green-500/20 shadow-[0_0_30px_rgba(34,197,94,0.1)] mb-8">
                    {selectedLesson.url.match(/\.(jpg|jpeg|png|gif|webp|svg)$/i) ? (
                      <div className="relative w-full h-64 md:h-96 lg:h-[500px]">
                        <Image
                          src={selectedLesson.url}
                          alt={selectedLesson.title}
                          fill
                          className="object-contain"
                          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 80vw, 70vw"
                        />
                      </div>
                    ) : (
                      <div className="relative w-full h-64 md:h-96 lg:h-[500px]">
                        <Image
                          src={selectedLesson.url}
                          alt={selectedLesson.title}
                          className="w-full h-full object-contain"
                        />
                      </div>
                    )}
                  </div>
                )}

                {/* Navigation Buttons */}
                <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-between">
                  <button
                    onClick={() => {
                      const currentIndex = currentModule.lessons?.findIndex(l => l.id === selectedLesson.id) || 0;
                      if (currentIndex > 0 && currentModule.lessons) {
                        setSelectedLesson(currentModule.lessons[currentIndex - 1]);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }
                    }}
                    disabled={!currentModule.lessons || currentModule.lessons.findIndex(l => l.id === selectedLesson.id) === 0}
                    className="flex items-center gap-2 px-6 py-3 bg-[#0A2228] border-2 border-green-500/30 rounded-xl font-bold hover:bg-[#0D2D35] hover:border-green-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ArrowLeft className="w-5 h-5" />
                    Previous Lesson
                  </button>

                  <button
                    onClick={() => {
                      const currentIndex = currentModule.lessons?.findIndex(l => l.id === selectedLesson.id) || 0;
                      if (currentModule.lessons && currentIndex < currentModule.lessons.length - 1) {
                        setSelectedLesson(currentModule.lessons[currentIndex + 1]);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      } else if (allLessonsCompleted && currentTest && !isReviewMode) {
                        setActiveTab('quiz');
                        resetQuiz();
                      }
                    }}
                    disabled={!allLessonsCompleted && currentModule.lessons?.findIndex(l => l.id === selectedLesson.id) === currentModule.lessons.length - 1}
                    className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${currentModule.lessons?.findIndex(l => l.id === selectedLesson.id) === currentModule.lessons.length - 1
                      ? allLessonsCompleted
                        ? 'bg-gradient-to-r from-yellow-500 to-accent-gold text-black hover:from-yellow-400 hover:to-yellow-300 shadow-[0_0_20px_rgba(212,175,55,0.3)]'
                        : 'bg-gray-700 text-gray-400 cursor-not-allowed'
                      : 'bg-green-500 text-black hover:bg-green-400 shadow-[0_0_20px_rgba(34,197,94,0.3)]'
                      }`}
                  >
                    {currentModule.lessons?.findIndex(l => l.id === selectedLesson.id) === currentModule.lessons.length - 1
                      ? allLessonsCompleted
                        ? isReviewMode ? 'Level Completed' : 'Take Quiz Challenge'
                        : 'Complete All Lessons'
                      : 'Next Lesson'
                    }
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-full p-8">
                <p className="text-gray-400 text-lg">Select a lesson from the sidebar to begin</p>
              </div>
            )}
          </main>
        </div>
      ) : (
        // QUIZ INTERFACE
        <div className="min-h-[calc(100vh-73px)] flex items-center justify-center p-6 md:p-12 relative overflow-hidden">
          {/* Background Effects */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-accent-gold/5 blur-[150px] rounded-full" />
          </div>

          <div className="w-full max-w-4xl relative z-10">
            {currentTest && !quizSubmitted ? (
              <>
                {/* Progress Header */}
                <div className="text-center mb-12">
                  <span className="inline-block px-4 py-2 rounded-full bg-accent-gold/10 border border-accent-gold/30 text-accent-gold text-sm font-black uppercase tracking-widest mb-4">
                    Mastery Test
                  </span>

                </div>

                <div className="mb-8 p-4 bg-[#0A2228]/50 rounded-xl border border-yellow-500/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-400">Progress</span>
                    <span className="text-sm font-bold text-yellow-400">
                      {currentQuestionIndex + 1}/{currentTest.questions.length} questions
                    </span>
                  </div>

                  <div className="w-full h-2 bg-[#05161A] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-accent-gold transition-all duration-500"
                      style={{
                        width: currentTest.questions.length
                          ? `${((currentQuestionIndex + 1) / currentTest.questions.length) * 100}%`
                          : '0%'
                      }}
                    />
                  </div>
                </div>


                {/* Question Card */}
                <div className="bg-[#051416] border-2 border-green-500/20 rounded-[2.5rem] p-8 md:p-12 shadow-2xl relative">
                  <h3 className="text-lg md:text-xl font-bold mb-10 leading-relaxed text-left">
                    <span className=" mr-2">
                      {currentQuestionIndex + 1})
                    </span>
                    {currentTest.questions[currentQuestionIndex].question}
                  </h3>


                  <div className="grid grid-cols-1 gap-4">
                    {(['option1', 'option2', 'option3', 'option4'] as const).map((optKey, idx) => {
                      const optionValue = currentTest.questions[currentQuestionIndex][optKey];
                      const isSelected = selectedAnswers[currentTest.questions[currentQuestionIndex].id] === (idx + 1);

                      return (
                        <button
                          key={idx}
                          onClick={() => handleOptionSelect(currentTest.questions[currentQuestionIndex].id, idx + 1)}
                          className={`w-full text-left p-6 rounded-2xl border-2 transition-all duration-300 flex items-center gap-4 group ${isSelected
                            ? 'bg-accent-gold/10 border-2 border-accent-gold text-white shadow-[0_0_20px_rgba(212,175,55,0.2)]'
                            : 'bg-[#0A2228] border-2 border-transparent hover:border-green-500/30 hover:bg-[#0D2D35] text-gray-300'
                            }`}
                        >
                          <span className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm transition-colors ${isSelected ? 'bg-accent-gold text-black' : 'bg-white/5 text-gray-500 group-hover:bg-white/10'
                            }`}>
                            {String.fromCharCode(65 + idx)}.
                          </span>
                          <span className="font-semibold text-[17px]">{optionValue}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Controls */}
                <div className="mt-10 flex justify-between items-center max-w-4xl mx-auto px-4">
                  <button
                    onClick={handlePrevQuestion}
                    disabled={currentQuestionIndex === 0}
                    className="flex items-center gap-2 px-6 py-3 bg-[#0A2228] border-2 border-green-500/30 rounded-xl font-bold hover:bg-[#0D2D35] hover:border-green-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ArrowLeft className="w-5 h-5" />
                    Previous
                  </button>

                  {currentQuestionIndex === currentTest.questions.length - 1 ? (
                    <button
                      onClick={calculateScore}
                      disabled={!selectedAnswers[currentTest.questions[currentQuestionIndex].id]}
                      className="px-10 py-4 bg-accent-gold text-black rounded-xl font-black hover:bg-yellow-400 transition-all shadow-[0_0_20px_rgba(212,175,55,0.3)] disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
                    >
                      Submit Test
                    </button>
                  ) : (
                    <button
                      onClick={handleNextQuestion}
                      disabled={!selectedAnswers[currentTest.questions[currentQuestionIndex].id]}
                      className="px-10 py-4 bg-green-500 text-black rounded-xl font-black hover:bg-green-400 transition-all shadow-[0_0_20px_rgba(34,197,94,0.3)] disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
                    >
                      Next Question
                    </button>
                  )}
                </div>
              </>
            ) : (
              // Quiz Results
              <div className="bg-[#051416] border-2 border-green-500/20 rounded-[2.5rem] p-12 text-center max-w-2xl mx-auto shadow-2xl">
                {(() => {
                  const correctPassed = currentTest ? score >= currentTest.passMark : false;
                  return (
                    <>
                      <div className={`w-24 h-24 ${correctPassed ? 'bg-green-500/10' : 'bg-red-500/10'} rounded-full flex items-center justify-center mx-auto mb-6`}>
                        {correctPassed ? (
                          <CheckCircle className="w-12 h-12 text-green-500" />
                        ) : (
                          <AlertCircle className="w-12 h-12 text-red-500" />
                        )}
                      </div>
                      <h2 className="text-3xl font-bold mb-2">
                        {correctPassed ? 'Congratulations!' : 'Quiz Completed'}
                      </h2>
                      <p className="text-gray-400 mb-2">
                        You scored: {score}/{totalQuestions}
                      </p>
                      <p className="text-lg mb-2">
                        {((score / totalQuestions) * 100).toFixed(1)}%
                      </p>
                      <p className={`text-lg font-bold mb-8 ${correctPassed ? 'text-green-500' : 'text-red-500'}`}>
                        {correctPassed ? 'PASSED ✓' : 'FAILED ✗'}
                      </p>
                      {currentTest?.passMark && (
                        <div className="text-sm text-gray-400 mb-8 space-y-1">
                          <p>Passing Mark: {currentTest.passMark} out of {totalQuestions} correct answers needed</p>
                          <p className={`text-xs ${correctPassed ? 'text-green-400' : 'text-red-400'}`}>
                            {score >= currentTest.passMark ?
                              `✓ You passed with ${score - currentTest.passMark} extra correct answer(s)` :
                              `✗ You needed ${currentTest.passMark - score} more correct answer(s) to pass`}
                          </p>
                        </div>
                      )}

                      <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        {correctPassed ? (
                          <>
                            {hasNextModule ? (
                              <button
                                onClick={handleStartNextLesson}
                                className="px-8 py-3 bg-green-500 text-black rounded-xl font-bold hover:bg-green-400 transition-all shadow-[0_0_20px_rgba(34,197,94,0.3)] flex items-center justify-center gap-2"
                              >
                                Start Next Lesson
                              </button>
                            ) : (
                              <button
                                onClick={() => router.push(`/premium-courses/${courseNumber}?completed=true`)}
                                className="px-8 py-3 bg-green-500 text-black rounded-xl font-bold hover:bg-green-400 transition-all shadow-[0_0_20px_rgba(34,197,94,0.3)] flex items-center justify-center gap-2"
                              >
                                Course Completed!
                              </button>
                            )}
                            <button
                              onClick={handleBackToLessons}
                              className="px-8 py-3 bg-[#0A2228] border-2 border-green-500/30 rounded-xl font-bold hover:border-green-500 transition-all"
                            >
                              Back to All Lessons
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={handleRetakeQuiz}
                              className="px-8 py-3 bg-accent-gold text-black rounded-xl font-bold hover:bg-yellow-400 transition-all shadow-[0_0_20px_rgba(212,175,55,0.3)] flex items-center justify-center gap-2"
                            >
                              Retake Quiz
                            </button>
                            <button
                              onClick={handleBackToLessons}
                              className="px-8 py-3 bg-[#0A2228] border-2 border-green-500/30 rounded-xl font-bold hover:border-green-500 transition-all"
                            >
                              Back to All Lessons
                            </button>
                          </>
                        )}
                      </div>
                    </>
                  );
                })()}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Result Alert Modal */}
      {showResultAlert && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-[#051416] border-2 border-green-500/20 rounded-[2.5rem] p-8 max-w-md w-full shadow-2xl animate-fade-in">
            {(() => {
              const correctPassed = currentTest ? score >= currentTest.passMark : false;
              return (
                <>
                  <div className={`w-20 h-20 ${correctPassed ? 'bg-green-500/10' : 'bg-red-500/10'} rounded-full flex items-center justify-center mx-auto mb-6`}>
                    {correctPassed ? (
                      <CheckCircle className="w-10 h-10 text-green-500" />
                    ) : (
                      <AlertCircle className="w-10 h-10 text-red-500" />
                    )}
                  </div>
                  <h3 className="text-2xl font-bold text-center mb-2">
                    Quiz Results
                  </h3>
                  <div className="text-center mb-6">
                    <p className="text-4xl font-black mb-2">
                      {score}/{totalQuestions}
                    </p>
                    <p className="text-lg mb-2">
                      {((score / totalQuestions) * 100).toFixed(1)}%
                    </p>
                    <p className={`text-lg font-bold ${correctPassed ? 'text-green-500' : 'text-red-500'}`}>
                      {correctPassed ? 'PASSED' : 'FAILED'}
                    </p>
                    {currentTest?.passMark && (
                      <div className="text-sm text-gray-400 mt-2 space-y-1">
                        <p>Passing Mark: {currentTest.passMark} out of {totalQuestions} correct answers needed</p>
                        <p className={`text-xs ${correctPassed ? 'text-green-400' : 'text-red-400'}`}>
                          {score >= currentTest.passMark ?
                            `✓ You passed with ${score - currentTest.passMark} extra correct answer(s)` :
                            `✗ You needed ${currentTest.passMark - score} more correct answer(s) to pass`}
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-3">
                    {correctPassed ? (
                      <>
                        {hasNextModule ? (
                          <button
                            onClick={handleStartNextLesson}
                            className="w-full py-4 bg-green-500 text-black rounded-xl font-bold hover:bg-green-400 transition-all shadow-[0_0_20px_rgba(34,197,94,0.3)]"
                          >
                            Start Next Lesson
                          </button>
                        ) : (
                          <button
                            onClick={() => router.push(`/premium-courses/${courseNumber}?completed=true`)}
                            className="w-full py-4 bg-green-500 text-black rounded-xl font-bold hover:bg-green-400 transition-all shadow-[0_0_20px_rgba(34,197,94,0.3)]"
                          >
                            Course Completed!
                          </button>
                        )}
                        <button
                          onClick={handleBackToLessons}
                          className="w-full py-4 bg-[#0A2228] border-2 border-green-500/30 rounded-xl font-bold hover:border-green-500 transition-all"
                        >
                          Back to All Lessons
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={handleRetakeQuiz}
                          className="w-full py-4 bg-accent-gold text-black rounded-xl font-bold hover:bg-yellow-400 transition-all shadow-[0_0_20px_rgba(212,175,55,0.3)]"
                        >
                          Retake Quiz
                        </button>
                        <button
                          onClick={handleBackToLessons}
                          className="w-full py-4 bg-[#0A2228] border-2 border-green-500/30 rounded-xl font-bold hover:border-green-500 transition-all"
                        >
                          Back to All Lessons
                        </button>
                      </>
                    )}
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* Exit Quiz Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-[#051416] border-2 border-green-500/20 rounded-[2.5rem] p-8 max-w-md w-full shadow-2xl animate-fade-in">
            <div className="flex justify-end mb-4">
              <button
                onClick={cancelExitQuiz}
                className="p-2 hover:bg-[#0A2228] rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-8 h-8 text-red-500" />
              </div>
              <h3 className="text-2xl font-bold mb-2">
                Are you sure?
              </h3>
              <p className="text-gray-400">
                Your quiz progress will be lost if you leave now. Do you want to continue?
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={cancelExitQuiz}
                className="flex-1 py-3 bg-[#0A2228] border-2 border-green-500/30 rounded-xl font-bold hover:border-green-500 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={confirmExitQuiz}
                className="flex-1 py-3 bg-red-500 text-white rounded-xl font-bold hover:bg-red-600 transition-all"
              >
                Yes, Leave Quiz
              </button>
            </div>
          </div>
        </div>   
      )}
    </div>
  );
}