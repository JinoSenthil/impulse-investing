'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import Navigation from '@/components/ui/Navigation'
import Footer from '@/components/ui/Footer'
import { Indicator } from '@/types'
import {
    ChevronLeft,
    CheckCircle2,
    ArrowRight,
    Loader2
} from 'lucide-react'
import { useSelector } from 'react-redux'
import { RootState } from '@/lib/store'

export default function IndicatorDetails() {
    const params = useParams()
    const router = useRouter()
    const id = params.id as string

    const { user } = useSelector((state: RootState) => state.auth)
    const userId = user?.id

    const [indicator, setIndicator] = useState<Indicator | null>(null)
    const [loading, setLoading] = useState(true)
    const [paymentLoading, setPaymentLoading] = useState(false)
    const [error, setError] = useState<string | null>(null)

    useEffect(() => {
        const fetchIndicator = async () => {
            if (!id) return;
            try {
                setLoading(true)
                const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/indicators/getOne/${id}`)
                if (!response.ok) throw new Error('Failed to fetch indicator details')
                const data = await response.json()
                setIndicator(data)
            } catch (err) {
                console.error('Error fetching indicator:', err)
                setError(err instanceof Error ? err.message : 'An error occurred')
            } finally {
                setLoading(false)
            }
        }

        fetchIndicator()
    }, [id])

    const handlePayment = async () => {
        if (!indicator || !userId) {
            setError('Please log in to make a purchase')
            return
        }

        try {
            setPaymentLoading(true)
            
            // Step 1: Create payment record
            const paymentResponse = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/payment/add`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id: 0,
                    transactionId: null,
                    amount: indicator.price,
                    paymentStatus: "PENDING",
                    paymentMethod: null,
                    paymentDetail: null,
                    createdDate: new Date().toISOString(),
                    modifiedDate: new Date().toISOString()
                })
            })

            if (!paymentResponse.ok) {
                throw new Error('Failed to create payment record')
            }

            const paymentData = await paymentResponse.json()
            const paymentId = paymentData.id

            // Step 2: Create indicator purchase record
            const purchaseResponse = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/indicatorPurchase/add`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id: 0,
                    userId: userId,
                    indicatorId: indicator.id,
                    amount: indicator.price,
                    purchaseDate: new Date().toISOString().split('T')[0],
                    createdDate: new Date().toISOString(),
                    modifiedDate: new Date().toISOString(),
                    paymentId: paymentId
                })
            })

            if (!purchaseResponse.ok) {
                throw new Error('Failed to create purchase record')
            }

            const purchaseData = await purchaseResponse.json()

            // Show success message and redirect to user dashboard or orders page
            alert('Payment initiated successfully! Your indicator will be activated shortly.')
            
              setTimeout(() => {
                router.push('/');
            }, 3000);
            
        } catch (err) {
            console.error('Payment error:', err)
            setError(err instanceof Error ? err.message : 'Payment failed. Please try again.')
        } finally {
            setPaymentLoading(false)
        }
    }

    if (loading) {
        return (
            <div className="min-h-screen bg-bg-primary text-text-primary">
                <Navigation />
                <div className="pt-32 pb-24 flex flex-col items-center justify-center min-h-[60vh]">
                    <Loader2 className="w-12 h-12 text-accent-gold animate-spin mb-4" />
                    <p className="text-text-secondary animate-pulse">Loading indicator intelligence...</p>
                </div>
                <Footer />
            </div>
        )
    }

    if (error || !indicator) {
        return (
            <div className="min-h-screen bg-bg-primary text-text-primary">
                <Navigation />
                <div className="pt-32 pb-24 px-6 max-w-5xl mx-auto text-center">
                    <div className="bg-red-500/10 border border-red-500/20 p-8 rounded-3xl mb-8">
                        <h1 className="text-2xl font-bold text-red-400 mb-4">Oops! Something went wrong</h1>
                        <p className="text-text-secondary">{error || 'Indicator not found'}</p>
                    </div>
                    <button
                        onClick={() => router.back()}
                        className="bg-white/5 hover:bg-white/10 px-8 py-3 rounded-xl transition"
                    >
                        Return to Indicators
                    </button>
                </div>
                <Footer />
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-bg-primary text-text-primary">
            <Navigation />

            <main className="pt-32 pb-24 px-6 md:px-12">
                <div className="max-w-6xl mx-auto">
                    {/* Back Link */}
                    <button
                        onClick={() => router.back()}
                        className="flex items-center gap-2 text-text-secondary hover:text-accent-gold transition mb-10 group"
                    >
                        <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
                        <span className="text-sm font-semibold uppercase tracking-wider">Back to Indicators</span>
                    </button>

                    <div className="bg-bg-card border-2 border-border/50 rounded-[2.5rem] overflow-hidden shadow-2xl relative">
                        {/* Background Decorative Glow */}
                        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-accent-gold/5 blur-[120px] rounded-full pointer-events-none" />

                        <div className="grid grid-cols-1 lg:grid-cols-12 relative z-10">
                            {/* Left Side: Product Image/Visual */}
                            <div className="lg:col-span-5 bg-[#051113] p-8 md:p-12 flex flex-col items-center justify-center border-b lg:border-b-0 lg:border-r border-border/50 overflow-hidden min-h-[400px]">
                                <div className="relative w-full aspect-square max-w-[400px] group">
                                    <div className="absolute inset-0 bg-accent-gold/20 blur-[60px] opacity-20 group-hover:opacity-40 transition-opacity" />
                                    <Image
                                        src={indicator.imageUrl && !indicator.imageUrl.includes('example.com') ? indicator.imageUrl : `/course${(indicator.id % 4) + 1}.png`}
                                        alt={indicator.title}
                                        fill
                                        className="object-cover rounded-3xl shadow-2xl ring-1 ring-white/10"
                                        priority
                                    />
                                </div>
                            </div>

                            {/* Right Side: Details */}
                            <div className="lg:col-span-7 p-8 md:p-14 space-y-10">
                                <div className="space-y-4">
                                    <div className="inline-flex items-center gap-2 bg-accent-gold/10 border border-accent-gold/20 px-4 py-1.5 rounded-full text-xs text-accent-gold font-black uppercase tracking-widest">
                                        Premium Indicator
                                    </div>
                                    <h1 className="font-cinzel text-4xl md:text-5xl font-black text-white leading-[1.1]">{indicator.title}</h1>
                                    <p className="text-text-secondary text-lg leading-relaxed max-w-2xl">
                                        {indicator.description}
                                    </p>
                                </div>

                                <div className="flex flex-wrap items-center gap-8 py-6 border-y border-border/50">
                                    <div>
                                        <div className="text-[10px] text-text-secondary font-black uppercase tracking-[0.2em] mb-1">Current Price</div>
                                        <div className="text-4xl font-black text-accent-gold">₹{indicator.price}/-</div>
                                    </div>
                                    <div className="h-12 w-px bg-border/50 hidden sm:block" />
                                    <div>
                                        <div className="text-[10px] text-text-secondary font-black uppercase tracking-[0.2em] mb-1">Availability</div>
                                        <div className="text-lg font-bold text-white flex items-center gap-2">
                                            <CheckCircle2 className="w-5 h-5 text-accent-green" />
                                            Instant Access
                                        </div>
                                    </div>
                                </div>

                                {/* Action Area */}
                                <div className="pt-8 space-y-6">
                                    <button
                                        onClick={handlePayment}
                                        disabled={paymentLoading || !userId}
                                        className={`w-full bg-gradient-to-r from-accent-gold to-[#c5a059] text-bg-primary py-5 rounded-2xl font-black text-sm uppercase tracking-[0.2em] shadow-2xl shadow-accent-gold/30 hover:brightness-110 hover:-translate-y-0.5 transition active:scale-[0.98] flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0`}
                                    >
                                        {paymentLoading ? (
                                            <>
                                                <Loader2 className="w-5 h-5 animate-spin" />
                                                Processing...
                                            </>
                                        ) : (
                                            <>
                                                Pay Now <ArrowRight className="w-5 h-5" />
                                            </>
                                        )}
                                    </button>

                                    {!userId && (
                                        <div className="text-center p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
                                            <p className="text-red-400 text-sm">
                                                Please log in to purchase this indicator.
                                            </p>
                                            <Link 
                                                href="/login" 
                                                className="text-accent-gold hover:underline text-sm font-semibold mt-2 inline-block"
                                            >
                                                Click here to login
                                            </Link>
                                        </div>
                                    )}

                                    <div className="flex flex-col items-center justify-center gap-4 text-text-secondary text-sm font-bold opacity-80">
                                        <p className="text-gray-400 text-sm text-center">
                                            Don&apos;t miss this opportunity to master the market with our premium indicator.
                                        </p>
                                        <div className="flex items-center gap-6">
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-accent-green" />
                                                <span>Instant Activation</span>
                                            </div>
                                            <div className="w-1 h-1 bg-white/20 rounded-full" />
                                            <span>24/7 Priority Support</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Disclaimer/Note */}
                    <div className="mt-12 p-8 bg-accent-gold/5 rounded-[2rem] border border-accent-gold/10">
                        <p className="text-text-secondary text-sm text-center leading-relaxed">
                            Every purchase comes with a comprehensive video setup guide and lifetime priority support from our technical experts. We ensure you&apos;re fully operational within minutes of enrollment.
                        </p>
                    </div>
                </div>
            </main>

            <Footer />
        </div>
    )
}