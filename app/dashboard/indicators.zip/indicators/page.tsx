'use client'

import { useState, useEffect } from 'react'
import DashboardPageWrapper from '@/components/ui/DashboardPageWrapper'
import { Activity, Zap, CheckCircle2, AlertCircle, FileText } from 'lucide-react'
import Link from 'next/link'
import { IndicatorPurchase } from '@/types'
import { useSelector } from 'react-redux'
import { RootState } from '@/lib/store'
import ApiService from '@/services/ApiService'

export default function MyIndicatorsPage() {
    const [indicatorPurchases, setIndicatorPurchases] = useState<IndicatorPurchase[]>([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState<string | null>(null)
    
    const { user } = useSelector((state: RootState) => state.auth)
    const userId = user?.id

    useEffect(() => {
        if (!userId) return

        const fetchIndicatorPurchases = async () => {
            try {
                setLoading(true)
                const purchases = await ApiService.getAllIndicatorPurchases(userId)
                setIndicatorPurchases(purchases || [])
                setError(null)
            } catch (err) {
                console.error('Failed to fetch indicator purchases:', err)
                setError('Failed to load your indicators. Please try again.')
            } finally {
                setLoading(false)
            }
        }

        fetchIndicatorPurchases()
    }, [userId])

    // Filter only successful purchases for display
    const successfulPurchases = indicatorPurchases.filter(
        purchase => purchase.paymentStatus === 'SUCCESS'
    )

    // Transform API data to match your component structure
    const indicators = successfulPurchases.map(purchase => ({
        name: purchase.title,
        status: 'Active',
        accuracy: '0%', 
        signals: 0,
        profitRate: '0%',
        lastSignal: 'No signals yet',
        type: getIndicatorType(purchase.title),
        color: 'text-accent-green',
        originalData: purchase
    }))

    const stats = [
        { 
            label: 'Active Indicators', 
            value: successfulPurchases.length.toString(), 
            icon: <Activity className="w-6 h-6 text-accent-gold" /> 
        },
        { 
            label: 'Total Signals', 
            value: '0',
            icon: <Zap className="w-6 h-6 text-accent-gold" /> 
        },
        { 
            label: 'Avg. Accuracy', 
            value: '0%',
            icon: <CheckCircle2 className="w-6 h-6 text-accent-gold" /> 
        },
    ]

    const getIndicatorType = (title: string): string => {
        const titleLower = title.toLowerCase()
        if (titleLower.includes('momentum') || titleLower.includes('rsi')) return 'Momentum'
        if (titleLower.includes('trend')) return 'Trend Following'
        if (titleLower.includes('volume')) return 'Volume Analysis'
        return 'Technical Indicator'
    }

    if (loading) {
        return (
            <DashboardPageWrapper title="My Indicators">
                <div className="flex items-center justify-center h-64">
                    <div className="text-center">
                        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-accent-gold mx-auto"></div>
                        <p className="mt-4 text-text-secondary">Loading your indicators...</p>
                    </div>
                </div>
            </DashboardPageWrapper>
        )
    }

    if (error) {
        return (
            <DashboardPageWrapper title="My Indicators">
                <div className="flex items-center justify-center h-64">
                    <div className="text-center">
                        <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                        <p className="text-text-secondary mb-4">{error}</p>
                        <button 
                            onClick={() => window.location.reload()}
                            className="bg-accent-gold text-bg-primary px-6 py-2 rounded-xl font-bold hover:bg-accent-gold/90 transition"
                        >
                            Retry
                        </button>
                    </div>
                </div>
            </DashboardPageWrapper>
        )
    }

    if (successfulPurchases.length === 0) {
        return (
            <DashboardPageWrapper title="My Indicators">
                <div className="bg-bg-card border-2 border-dashed border-border rounded-3xl p-12 text-center">
                    <div className="w-16 h-16 bg-bg-secondary rounded-2xl flex items-center justify-center mx-auto mb-6">
                        <FileText className="w-8 h-8 text-text-secondary opacity-50" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">
                      {indicatorPurchases.length === 0 && 'No Indicators Yet'}

                    </h3>
                    <p className="text-text-secondary mb-8 max-w-sm mx-auto">
                        {indicatorPurchases.length > 0 &&  'You have not purchased any indicators yet. Start your trading journey by exploring our catalog.'
                        }
                    </p>
                    <Link
                        href="/#indicators"
                        className="bg-accent-gold text-bg-primary px-8 py-3 rounded-xl font-bold hover:bg-accent-gold/90 transition"
                    >
                        {indicatorPurchases.length > 0  &&  'Browse Indicators'}
                    </Link>
                </div>
            </DashboardPageWrapper>
        )
    }

    return (
        <DashboardPageWrapper title="My Indicators">
            {/* Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mb-6">
                {stats.map((stat, idx) => (
                    <div key={idx} className="bg-bg-card border-2 border-border rounded-2xl p-5 md:p-6 hover:border-accent-gold transition">
                        <div className="flex items-center gap-4 mb-3">
                            <div className="bg-bg-secondary p-3 rounded-xl">{stat.icon}</div>
                            <span className="text-xs md:text-sm text-text-secondary uppercase tracking-wider">{stat.label}</span>
                        </div>
                        <div className="text-2xl md:text-3xl font-bold">{stat.value}</div>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 md:gap-8">
                {/* Active Indicators */}
                <div className="space-y-6">
                    <h2 className="text-xl md:text-2xl font-bold mb-4 md:mb-6">Active Indicators</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-6">
                        {indicators.map((indicator, idx) => (
                            <div key={idx} className="bg-bg-card border-2 border-border rounded-2xl p-5 md:p-6 hover:border-accent-gold transition">
                                <div className="flex justify-between items-start mb-4">
                                    <div>
                                        <h3 className="text-lg md:text-xl font-bold mb-1">{indicator.name}</h3>
                                        <span className="text-xs md:text-sm text-text-secondary">{indicator.type}</span>
                                    </div>
                                    <span className="bg-accent-green/20 text-accent-green px-3 py-1 rounded-full text-[10px] md:text-xs font-bold">
                                        {indicator.status}
                                    </span>
                                </div>

                                <div className="grid grid-cols-2 gap-4 mb-4">
                                    <div>
                                        <div className="text-[10px] md:text-xs text-text-secondary mb-1">Accuracy</div>
                                        <div className="text-xl md:text-2xl font-bold text-accent-gold">{indicator.accuracy}</div>
                                    </div>
                                    <div>
                                        <div className="text-[10px] md:text-xs text-text-secondary mb-1">Profit Rate</div>
                                        <div className={`text-xl md:text-2xl font-bold ${indicator.color}`}>{indicator.profitRate}</div>
                                    </div>
                                </div>

                                <div className="flex justify-between text-[10px] md:text-xs border-t border-border pt-4">
                                    <span className="text-text-secondary">Signals: <span className="text-text-primary font-semibold">{indicator.signals}</span></span>
                                    <span className="text-text-secondary">Last: <span className="text-text-primary font-semibold">{indicator.lastSignal}</span></span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Recent Signals */}
                <div>
                    <h2 className="text-xl md:text-2xl font-bold mb-4 md:mb-6">Recent Signals</h2>
                    <div className="bg-bg-card border-2 border-border rounded-2xl overflow-hidden">
                        <div className="divide-y divide-border">
                            <div className="p-8 text-center text-text-secondary">
                                <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
                                <p>No signals yet. Signals will appear here once generated.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* CTA */}
            <div className="mt-12 bg-gradient-to-r from-accent-gold/10 to-transparent border-2 border-accent-gold/30 rounded-2xl p-6 md:p-8 text-center md:text-left flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                    <h3 className="text-xl md:text-2xl font-bold mb-2">Need More Indicators?</h3>
                    <p className="text-text-secondary text-sm md:text-base">Browse our Products page for Premium Indicators</p>
                </div>
                <Link
                    href="/#indicators" 
                    className="w-full md:w-auto bg-accent-gold text-bg-primary px-8 py-3 rounded-xl font-bold hover:bg-accent-gold/90 transition"
                >
                    Explore Products
                </Link>
            </div>
        </DashboardPageWrapper>
    )
}