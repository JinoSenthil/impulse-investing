'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import DashboardPageWrapper from '@/components/ui/DashboardPageWrapper'
import { FileText, CheckCircle2, TrendingUp } from 'lucide-react'
import Link from 'next/link'
import { OnlineCourse } from '@/types'
import ApiService from '@/services/ApiService'
import { useRouter } from 'next/navigation'
import { useSelector } from 'react-redux'
import { RootState } from '@/lib/store'
import Pagination from '@/components/ui/Pagination'
import { getFullImageUrl } from '@/lib/utils'


export default function MyCoursesPage() {
    const [enrolledCourses, setEnrolledCourses] = useState<OnlineCourse[]>([])
    const [loading, setLoading] = useState(true)

    const router = useRouter()

    const { user } = useSelector((state: RootState) => state.auth)
    const userId = user?.id

    const [currentPage, setCurrentPage] = useState(1)
    const itemsPerPage = 6

    useEffect(() => {
        if (!user) {
            router.push('/login')
            return
        }

        const fetchCourses = async () => {
            try {
                if (userId) {
                    const data = await ApiService.getAllOnlineCourses(userId)
                    setEnrolledCourses(data || [])
                }
            } catch (err) {
                console.log('Failed to fetch courses:', err)
            } finally {
                setLoading(false)
            }
        }

        fetchCourses()
    }, [user, userId, router])

    const totalPages = Math.ceil(enrolledCourses.length / itemsPerPage)
    const startIndex = (currentPage - 1) * itemsPerPage
    const currentCourses = enrolledCourses.slice(startIndex, startIndex + itemsPerPage)

    const stats = [
        {
            label: 'Courses Enrolled',
            value: enrolledCourses.length.toString(),
            icon: <FileText className="w-6 h-6 text-accent-gold" />
        },
        {
            label: 'Paid Courses',
            value: enrolledCourses.filter(course => course.isPaid).length.toString(),
            icon: <TrendingUp className="w-6 h-6 text-accent-gold" />
        },
        {
            label: 'Free Courses',
            value: enrolledCourses.filter(course => !course.isPaid).length.toString(),
            icon: <CheckCircle2 className="w-6 h-6 text-accent-gold" />
        },
    ]

    if (loading) {
        return (
            <DashboardPageWrapper title="My Courses">
                <div className="flex justify-center items-center py-20">
                    <div className="text-2xl text-accent-gold animate-pulse">Loading your courses...</div>
                </div>
            </DashboardPageWrapper>
        )
    }


    return (
        <DashboardPageWrapper title="My Courses">
            {/* Stats Overview - Dynamic */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mb-6">
                {stats.map((stat, idx) => (
                    <div key={idx} className="bg-bg-card border-2 border-border rounded-2xl p-5 md:p-6 hover:border-accent-gold transition">
                        <div className="flex items-center gap-4 mb-3">
                            <div className="bg-bg-secondary p-3 rounded-xl">{stat.icon}</div>
                            <span className="text-xs md:text-sm text-text-secondary uppercase tracking-wider">{stat.label}</span>
                        </div>
                        <div className="text-2xl md:text-3xl font-bold">{stat.value}</div>
                    </div>
                ))}
            </div>

            {/* Course List - Dynamic */}
            <div className="space-y-6">
                {currentCourses.length > 0 ? (
                    <>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {currentCourses.map((course) => {
                                const imageUrl = getFullImageUrl(course.coverImage || course.thumbnailImgUrl)
                                const hasThumbnail = !!imageUrl && (course.coverImage || course.thumbnailImgUrl) !== 'string'


                                return (
                                    <div
                                        key={course.id}
                                        className="bg-bg-card border-2 border-border rounded-2xl p-6 hover:border-accent-gold transition group h-full flex flex-col"
                                    >
                                        <h3 className="font-cinzel text-xl font-bold text-white group-hover:text-accent-gold transition-colors line-clamp-2 mb-4">
                                            {course.title}
                                        </h3>

                                        <div
                                            className="text-text-secondary text-sm mb-6 leading-relaxed line-clamp-3 flex-grow"
                                            dangerouslySetInnerHTML={{ __html: course.shortDescription || '' }}
                                        />

                                        <div className="mb-6 rounded-xl overflow-hidden border border-accent-gold/20 relative h-48 w-full z-10">
                                            <Image
                                                src={hasThumbnail ? imageUrl : "/noimage.webp"}
                                                alt={course.title}
                                                fill
                                                className={`object-cover transition-transform duration-700 group-hover:scale-110 ${!hasThumbnail ? 'opacity-50 grayscale' : ''}`}
                                            />
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                                        </div>

                                        <div className="flex flex-wrap items-center justify-between gap-4 mb-6 text-text-secondary text-sm mt-auto">

                                            <div className="flex items-center gap-2">
                                                {course.isPaid ? (
                                                    <span className="px-3 py-1 rounded-full border border-accent-gold/30 bg-accent-gold/5 text-accent-gold text-xs font-bold uppercase">
                                                        ₹{course.discountPrice || course.price}
                                                    </span>
                                                ) : (
                                                    <span className="px-3 py-1 rounded-full border border-green-500/30 bg-green-500/5 text-green-500 text-xs font-bold uppercase">
                                                        Free
                                                    </span>
                                                )}
                                            </div>
                                        </div>

                                    </div>
                                )
                            })}
                        </div>

                        <Pagination
                            currentPage={currentPage}
                            totalPages={totalPages}
                            onPageChange={(page) => setCurrentPage(page)}
                        />
                    </>
                ) : (
                    <div className="bg-bg-card border-2 border-dashed border-border rounded-3xl p-12 text-center">
                        <div className="w-16 h-16 bg-bg-secondary rounded-2xl flex items-center justify-center mx-auto mb-6">
                            <FileText className="w-8 h-8 text-text-secondary opacity-50" />
                        </div>
                        <h3 className="text-xl font-bold mb-2">No Courses Enrolled</h3>
                        <p className="text-text-secondary mb-8 max-w-sm mx-auto">
                            You have not enrolled in any courses yet. Start your trading journey by exploring our catalog.
                        </p>
                        <Link
                            href="/#courses"
                            className="bg-accent-gold text-bg-primary px-8 py-3 rounded-xl font-bold hover:bg-accent-gold/90 transition"
                        >
                            Browse Courses
                        </Link>
                    </div>
                )}
            </div>

            {enrolledCourses.length > 0 && (
                <div className="mt-12 bg-gradient-to-r from-accent-gold/10 to-transparent border-2 border-accent-gold/30 rounded-2xl p-6 md:p-8 text-center md:text-left flex flex-col md:flex-row items-center justify-between gap-6">
                    <div>
                        <h3 className="text-xl md:text-2xl font-bold mb-2">Want to Buy More Courses?</h3>
                        <p className="text-text-secondary text-sm md:text-base">
                            Explore and enroll in more premium trading courses
                        </p>
                    </div>
                    <Link
                        href="/premium-courses"
                        className="w-full md:w-auto text-center bg-accent-gold text-bg-primary px-8 py-3 rounded-xl font-bold hover:bg-accent-gold/90 transition"
                    >
                        View All Courses
                    </Link>
                </div>
            )}

        </DashboardPageWrapper>
    )
}