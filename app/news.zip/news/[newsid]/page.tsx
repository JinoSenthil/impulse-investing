'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import ApiService from '@/services/ApiService'
import { NewsItem } from '@/types'
import { Clock, Image as ImageIcon, ArrowLeft, ChevronLeft, ChevronRight } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'
import { getFullImageUrl } from '@/lib/utils'
import { motion } from 'framer-motion'

export default function NewsDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const newsid = params?.newsid

  const [categoryNews, setCategoryNews] = useState<NewsItem[]>([])
  const [categoryName, setCategoryName] = useState<string>('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [currentNews, setCurrentNews] = useState<NewsItem | null>(null)


  useEffect(() => {
    const fetchNewsByCategory = async () => {
      try {
        if (!newsid) return
        
        // First, get all news to find the clicked one
        const allNews = await ApiService.getAllNews()
        
        // Find the clicked news item to get its category ID
        const clickedNews = allNews.find(item => item.id === Number(newsid))
        
        if (!clickedNews) {
          throw new Error('News not found')
        }
        
        setCurrentNews(clickedNews)
        
        // Get newsCategoryId from the clicked news
        const categoryId = clickedNews.newsCategoryId
        
        if (!categoryId) {
          throw new Error('No category found for this news')
        }
        
        // Fetch all news from this category
        const newsInCategory = await ApiService.getAllNews({ 
          newsCategoryId: categoryId,
          newsStatus: "PUBLISHED"
        })
        
        // Filter only active news
        const activeNews = newsInCategory.filter(item => item.activeStatus)
        
        setCategoryNews(activeNews)
        
        // Set category name (use newsCategoryName from clicked news or default)
        setCategoryName(clickedNews.newsCategoryName || 'News Category')
        
      } catch (err) {
        console.error('Failed to fetch news:', err)
        setError(err instanceof Error ? err.message : 'Failed to load news details')
      } finally {
        setLoading(false)
      }
    }

    fetchNewsByCategory()
  }, [newsid])

  if (loading) {
    return (
      <div className="min-h-screen bg-[#020C0E] flex items-center justify-center">
        <div className="text-green-500 font-cinzel text-2xl animate-pulse">
          Loading News...
        </div>
      </div>
    )
  }

  if (error || !currentNews || categoryNews.length === 0) {
    return (
      <div className="min-h-screen bg-[#020C0E] flex flex-col items-center justify-center text-white gap-4">
        <h1 className="text-2xl font-bold text-red-500">
          {error || 'News Not Found'}
        </h1>
        <Link href="/#news" className="text-accent-gold hover:underline">
          Return to News
        </Link>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#020C0E] text-white">
      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-green-500/5 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-accent-gold/5 blur-[120px] rounded-full" />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#05161A]/80 backdrop-blur-xl border-b border-green-500/10 px-6 py-4 shadow-2xl">
        <div className="w-[90%] max-w-[1800px] mx-auto flex items-center justify-between">
          <Link
              href="/#news"
            className="flex items-center gap-2 text-text-secondary hover:text-green-400 transition-colors font-semibold group"
          >
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="hidden sm:inline">Back to All News</span>
          </Link>

          <div className="text-center">
            <h1 className="font-cinzel text-lg sm:text-xl font-bold tracking-[2px] text-green-500">
              {categoryName}
            </h1>
           
          </div>

          <Link
            href="/"
            className="text-text-secondary hover:text-green-500 font-semibold text-sm"
          >
            Home
          </Link>
        </div>
      </header>

      {/* Main Content - Show all news from this category */}
      <main className="relative z-10 w-[90%] max-w-[1800px] mx-auto px-6 py-12">
        {/* Featured/Clicked News (Highlighted) */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold mb-8 text-accent-gold border-b border-accent-gold/30 pb-3">
            Featured Article
          </h2>
          
          <div className="bg-gradient-to-r from-green-500/10 to-accent-gold/5 border-2 border-accent-gold/30 rounded-2xl p-8 hover:border-accent-gold transition-all duration-300">
            {/* Image */}
            {currentNews.imageUrl && currentNews.imageUrl !== 'string' ? (
              <div className="relative w-full h-[400px] mb-6 rounded-2xl overflow-hidden">
                <Image
                  src={getFullImageUrl(currentNews.imageUrl)}
                  alt={currentNews.title}
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            ) : (
              <div className="w-full h-[400px] bg-bg-card rounded-2xl flex items-center justify-center mb-6">
                <ImageIcon className="w-16 h-16 text-text-secondary/50" />
              </div>
            )}

            {/* Category & Status */}
            <div className="flex items-center justify-between mb-4">
              <span className="text-accent-gold font-semibold">
                {categoryName}
              </span>
              <span className="flex items-center gap-2 text-xs bg-green-500/20 text-green-400 px-3 py-1 rounded-full">
                <Clock className="w-4 h-4" /> Published
              </span>
            </div>

            {/* Title */}
            <h1 className="text-4xl md:text-5xl font-bold mb-6">{currentNews.title}</h1>

            {/* Short Description if available */}
            {currentNews.shortDescription && (
              <p className="text-xl text-accent-gold mb-6 font-medium">
                {currentNews.shortDescription}
              </p>
            )}

            {/* Full Description */}
            <div className="prose prose-lg max-w-none">
              <div className="text-text-secondary text-lg leading-relaxed whitespace-pre-line">
                {currentNews.description}
              </div>
            </div>
          </div>
        </div>

        {/* Other News in Same Category */}
        <div>
          <h2 className="text-2xl font-bold mb-8 text-accent-gold border-b border-accent-gold/30 pb-3">
            More from {categoryName}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categoryNews
              .filter(item => item.id !== currentNews.id) // Exclude current news
              .map((item, index) => (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  key={item.id}
                >
                  <Link href={`/news/${item.id}`} className="block h-full">
                    <div className="bg-bg-card border-2 border-border rounded-2xl p-6 hover:border-accent-gold transition-all duration-300 group cursor-pointer h-full flex flex-col">
                      {/* Image Section */}
                      {item.imageUrl && item.imageUrl !== "string" ? (
                        <div className="relative h-48 mb-4 overflow-hidden rounded-lg flex-shrink-0">
                          <Image
                            src={getFullImageUrl(item.imageUrl)}
                            alt={item.title}
                            fill
                            className="object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      ) : (
                        <div className="h-48 mb-4 bg-gradient-to-br from-[#0C2D2A] to-[#05161A] rounded-lg flex items-center justify-center border border-border flex-shrink-0">
                          <ImageIcon className="w-12 h-12 text-text-secondary/50" />
                        </div>
                      )}

                      {/* Category and Status */}
                      <div className="flex items-center justify-between mb-4 flex-shrink-0">
                        <span className="text-sm text-accent-gold font-semibold truncate">
                          {categoryName}
                        </span>
                        <span className="flex items-center gap-1 text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded-full">
                          <Clock className="w-3 h-3" /> Published
                        </span>
                      </div>

                      {/* Title */}
                      <h3 className="text-xl font-bold mb-3 text-white group-hover:text-accent-gold transition line-clamp-2 flex-shrink-0 h-[56px]">
                        {item.title}
                      </h3>

                      {/* Description */}
                      <p className="text-text-secondary mb-4 line-clamp-3 flex-shrink-0 h-[72px]">
                        {item.shortDescription || item.description}
                      </p>

                      {/* Read More */}
                      <div className="flex items-center justify-between text-sm text-text-secondary mt-auto pt-4 border-t border-border/50 flex-shrink-0">
                        <span className="text-accent-gold group-hover:translate-x-1 transition">
                          Read Full Article →
                        </span>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
          </div>
        </div>
      </main>

      <footer className="py-12 border-t border-white/5 text-center">
        <p className="text-text-secondary text-sm font-medium">
          &copy; {new Date().getFullYear()} IMPULSE TRADING ACADEMY.
        </p>
        <p className="text-text-secondary text-xs mt-2">
          Category: {categoryName} • {categoryNews.length} Articles
        </p>
      </footer>
    </div>
  )
}