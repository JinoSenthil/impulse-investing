'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Menu, X, User as UserIcon, LogOut, LayoutDashboard, ChevronDown, Crown, LogIn } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { useDispatch, useSelector } from 'react-redux'
import { RootState } from '@/lib/store'
import { logout } from '@/lib/features/auth/authSlice'
import { usePathname } from 'next/navigation'

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isProfileOpen, setIsProfileOpen] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [activeSection, setActiveSection] = useState('')
  const pathname = usePathname()
  const dispatch = useDispatch()
  const { isAuthenticated, user } = useSelector((state: RootState) => state.auth)

  const handleLogout = () => {
    dispatch(logout())
    setIsMenuOpen(false)
  }

  useEffect(() => {
    setMounted(true)
    
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)

      // Detect active section
      const sections = ['about', 'features', 'indicators', 'courses', 'news', 'contact']
      const scrollPosition = window.scrollY + 100 // Offset for better detection

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const { offsetTop, offsetHeight } = element
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(`#${section}`)
            break
          }
        }
      }
    }

    const handleClickOutside = (e: MouseEvent) => {
      if (isProfileOpen && !(e.target as Element).closest('.profile-dropdown')) {
        setIsProfileOpen(false)
      }
    }

    window.addEventListener('scroll', handleScroll)
    window.addEventListener('click', handleClickOutside)
    
    // Initial check
    handleScroll()

    return () => {
      window.removeEventListener('scroll', handleScroll)
      window.removeEventListener('click', handleClickOutside)
    }
  }, [isProfileOpen])

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }
  }, [isMenuOpen])

  const navLinks = [
    { href: '/#about', label: 'About', isAnchor: true },
    { href: '/#features', label: 'Features', isAnchor: true },
    { href: '/#indicators', label: 'Products', isAnchor: true },
    { href: '/#courses', label: 'Courses', isAnchor: true },
    { href: '/premium-courses', label: 'Premium Courses', isAnchor: false, isPremium: true },
    { href: '/#news', label: 'News', isAnchor: true },
    { href: '/#contact', label: 'Contact', isAnchor: true },
  ]

  const isActive = (href: string) => {
    // For non-anchor links (like /premium-courses)
    if (!href.includes('#')) {
      return pathname === href
    }
    
    // For anchor links
    const hash = href.split('#')[1]
    return activeSection === `#${hash}` && pathname === '/'
  }

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-bg-primary/95 backdrop-blur-xl border-b border-white/10' : 'bg-transparent'
      }`}>
      <div className="w-[95%] max-w-[1700px] mx-auto px-4 sm:px-6 py-4 flex justify-between items-center">
        <Link href="/" className="flex items-center gap-3 group">
          <Image
            src="/logo2.png"
            alt="Logo"
            width={45}
            height={45}
            className="h-10 w-auto object-contain transition-transform group-hover:scale-105"
            priority
          />
          <span className="font-cinzel text-xl sm:text-2xl font-bold tracking-[2px] text-accent-gold transition-colors">
            IMPULSE
          </span>
        </Link>

        {/* Desktop Navigation */}
        <ul className="hidden lg:flex gap-6 xl:gap-8 items-center">
          {navLinks.map((link) => (
            <li key={link.href}>
              {link.isPremium ? (
                <Link
                  href={link.href}
                  className={`flex items-center gap-1.5 transition font-bold text-sm group ${
                    isActive(link.href)
                      ? 'text-accent-gold'
                      : 'text-accent-green hover:text-green-400'
                  }`}
                >
                  <Crown size={16} className="transition-transform group-hover:scale-110" />
                  {link.label}
                </Link>
              ) : link.isAnchor ? (
                <a 
                  href={link.href} 
                  className={`transition font-medium text-sm ${
                    isActive(link.href)
                      ? 'text-accent-gold font-bold'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  {link.label}
                </a>
              ) : (
                <Link 
                  href={link.href} 
                  className={`transition font-medium text-sm ${
                    isActive(link.href)
                      ? 'text-accent-gold font-bold'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  {link.label}
                </Link>
              )}
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-4">
          {mounted && (
            <>
              {isAuthenticated ? (
                <div className="relative profile-dropdown">
                  <button
                    onClick={() => setIsProfileOpen(!isProfileOpen)}
                    className="flex items-center gap-3 bg-white/5 hover:bg-white/10 p-1.5 pr-4 rounded-full border border-white/10 transition-all group"
                  >
                    <div className="w-9 h-9 bg-accent-gold rounded-full flex items-center justify-center text-bg-primary shadow-lg shadow-accent-gold/20">
                      <UserIcon size={18} />
                    </div>
                    <div className="flex flex-col items-start min-w-0 max-w-[120px]">
                      <span className="text-xs font-bold text-white truncate w-full">
                        {user?.firstName} {user?.lastName}
                      </span>
                      <span className="text-[10px] text-accent-gold font-black uppercase tracking-wider">
                        {user?.isPremium ? 'Elite' : 'Member'}
                      </span>
                    </div>
                    <ChevronDown size={14} className={`text-gray-400 transition-transform duration-300 ${isProfileOpen ? 'rotate-180' : ''}`} />
                  </button>

                  <AnimatePresence>
                    {isProfileOpen && (
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 mt-3 w-56 bg-[#0a0a0a] border border-white/10 rounded-2xl shadow-2xl overflow-hidden py-1.5"
                      >
                        <Link
                          href="/dashboard"
                          onClick={() => setIsProfileOpen(false)}
                          className="flex items-center gap-3 px-5 py-3 text-sm text-gray-300 hover:text-white hover:bg-white/5 transition"
                        >
                          <LayoutDashboard size={16} />
                          Dashboard
                        </Link>
                        <button
                          onClick={handleLogout}
                          className="w-full flex items-center gap-3 px-5 py-3 text-sm text-red-500 hover:bg-red-500/10 transition"
                        >
                          <LogOut size={16} />
                          Logout
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <Link
                  href="/login"
                  className="flex items-center gap-2 border border-accent-green/30 px-6 py-2 rounded-xl text-accent-green font-bold text-sm hover:bg-accent-green hover:text-black transition-all shadow-[0_0_15px_rgba(34,197,94,0.1)]"
                >
                  <LogIn size={18} />
                  Login
                </Link>
              )}
            </>
          )}

          {!mounted && (
            <div className="w-24 h-9 bg-white/5 rounded-xl animate-pulse" />
          )}

          {/* Mobile Toggle */}
          <button
            className="lg:hidden p-2 text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              className="fixed inset-0 bg-black/90 backdrop-blur-md z-40 lg:hidden"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-screen w-[300px] bg-[#050505] border-l border-white/10 z-50 lg:hidden p-8 flex flex-col"
            >
              <div className="flex justify-between items-center mb-10">
                <Link href="/" className="flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
                  <Image src="/logo2.png" alt="Logo" width={30} height={30} />
                  <span className="font-cinzel text-lg font-bold text-accent-gold">IMPULSE</span>
                </Link>
                <button onClick={() => setIsMenuOpen(false)} className="text-white">
                  <X size={24} />
                </button>
              </div>

              <ul className="flex flex-col gap-5 flex-grow">
                {navLinks.map((link) => (
                  <li key={link.href}>
                    {link.isPremium ? (
                      <Link
                        href={link.href}
                        onClick={() => setIsMenuOpen(false)}
                        className={`text-xl transition font-bold flex items-center gap-2 ${
                          isActive(link.href)
                            ? 'text-accent-gold'
                            : 'text-accent-green hover:text-green-400'
                        }`}
                      >
                        <Crown size={20} />
                        {link.label}
                      </Link>
                    ) : link.isAnchor ? (
                      <a
                        href={link.href}
                        onClick={() => setIsMenuOpen(false)}
                        className={`text-xl transition font-medium block ${
                          isActive(link.href)
                            ? 'text-accent-gold font-bold'
                            : 'text-gray-300 hover:text-white'
                        }`}
                      >
                        {link.label}
                      </a>
                    ) : (
                      <Link
                        href={link.href}
                        onClick={() => setIsMenuOpen(false)}
                        className={`text-xl transition font-medium block ${
                          isActive(link.href)
                            ? 'text-accent-gold font-bold'
                            : 'text-gray-300 hover:text-white'
                        }`}
                      >
                        {link.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>

              <div className="mt-auto pt-8 border-t border-white/10">
                {mounted && (
                  <>
                    {isAuthenticated ? (
                      <div className="flex flex-col gap-4">
                        <div className="flex items-center gap-4 mb-4">
                          <div className="w-12 h-12 bg-accent-gold rounded-full flex items-center justify-center text-bg-primary">
                            <UserIcon size={20} />
                          </div>
                          <div>
                            <p className="text-white font-bold">{user?.firstName} {user?.lastName}</p>
                            <p className="text-xs text-accent-gold font-black uppercase">{user?.isPremium ? 'Elite' : 'Member'}</p>
                          </div>
                        </div>
                        <Link
                          href="/dashboard"
                          onClick={() => setIsMenuOpen(false)}
                          className="flex items-center gap-3 text-lg text-gray-300 hover:text-white py-2"
                        >
                          <LayoutDashboard size={20} />
                          Dashboard
                        </Link>
                        <button
                          onClick={handleLogout}
                          className="flex items-center gap-3 text-lg text-red-500 hover:text-red-400 py-2"
                        >
                          <LogOut size={20} />
                          Logout
                        </button>
                      </div>
                    ) : (
                      <Link
                        href="/login"
                        onClick={() => setIsMenuOpen(false)}
                        className="w-full flex justify-center items-center gap-2 border border-accent-green px-7 py-3 rounded-xl text-accent-green font-bold text-lg hover:bg-accent-green hover:text-black transition-all"
                      >
                        <LogIn size={20} />
                        Login
                      </Link>
                    )}
                  </>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </nav>
  )
}
