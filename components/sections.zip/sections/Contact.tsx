'use client'

import { useState } from 'react'
import { Mail, Phone, MessageSquare, Send, Loader2 } from 'lucide-react'
import ApiService from '@/services/ApiService'
import { useSelector } from 'react-redux'
import { RootState } from '@/lib/store'
import { ContactData } from '@/types'

export default function Contact() {
  const { user } = useSelector((state: RootState) => state.auth)
  console.log("User :", user)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState<ContactData>({
    name: '',
    email: '',
    mobileNumber: '',
    subject: '',
    message: ''
  })

  const [fieldErrors, setFieldErrors] = useState<Record<string, boolean>>({})
  const [mobileError, setMobileError] = useState<string>('')

  const validateForm = () => {
    const errors: Record<string, boolean> = {}
    let isValid = true

    // Check for empty required fields
    if (!formData.name.trim()) {
      errors.name = true
      isValid = false
    }
    if (!formData.email.trim()) {
      errors.email = true
      isValid = false
    }
    if (!formData.mobileNumber.trim()) {
      errors.mobileNumber = true
      isValid = false
    }
    if (!formData.subject.trim()) {
      errors.subject = true
      isValid = false
    }
 

    // Validate mobile number
    if (formData.mobileNumber.trim()) {
      if (formData.mobileNumber.length !== 10) {
        setMobileError('Mobile number must be 10 digits')
        isValid = false
      } else {
        setMobileError('')
      }
    }

    setFieldErrors(errors)
    return isValid
  }

  const handleFieldChange = (field: keyof ContactData, value: string) => {
    setFormData({ ...formData, [field]: value })
    
    // Clear field error when user starts typing
    if (fieldErrors[field] && value.trim()) {
      const newErrors = { ...fieldErrors }
      delete newErrors[field]
      setFieldErrors(newErrors)
    }

    // Clear mobile error when user starts typing
    if (field === 'mobileNumber' && mobileError) {
      setMobileError('')
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validate form before submission
    if (!validateForm()) {
      return
    }

    setLoading(true)
    setError(null)
    setSuccess(false)

    try {
      await ApiService.createContact({
        id: 0,
        ...formData,
        createdDate: new Date().toISOString(),
        modifiedDate: new Date().toISOString()
      })
      setSuccess(true)
      // Reset form on success
      setFormData({
        name: '',
        email: '',
        mobileNumber: '',
        subject: '',
        message: ''
      })
      // Clear all errors
      setFieldErrors({})
      setMobileError('')
    } catch (err: unknown) {
      console.error('Contact form submission failed:', err)
      const errorMessage = err instanceof Error ? err.message : 'Something went wrong. Please try again.'
      setError(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  return (
    <section id="contact" className="py-20 px-6 bg-bg-secondary">
      <div className="w-[90%] max-w-[1800px] mx-auto">
        <div className="text-center mb-16">
          <div className="text-sm text-accent-gold uppercase tracking-[2px] mb-4">Get in Touch</div>
          <h2 className="font-cinzel text-5xl font-bold mb-6">
            Contact <span className="text-accent-gold">Us</span>
          </h2>
          <p className="text-text-secondary text-lg max-w-[600px] mx-auto">
            We&apos;re here to help you succeed. Reach out to us anytime.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div className="space-y-8">
            <div className="bg-bg-card border-2 border-border rounded-2xl p-6 hover:border-accent-gold transition">
              <div className="mb-4"><Mail className="w-12 h-12 text-accent-gold" /></div>
              <h3 className="text-2xl font-bold mb-2">Email Us</h3>
              <p className="text-text-secondary mb-4">For general inquiries and support</p>
              <p className="text-accent-gold">support@impulse.com</p>
              <p className="text-accent-gold">hello@impulse.com</p>
            </div>

            <div className="bg-bg-card border-2 border-border rounded-2xl p-6 hover:border-accent-gold transition">
              <div className="mb-4"><Phone className="w-12 h-12 text-accent-gold" /></div>
              <h3 className="text-2xl font-bold mb-2">Call Us</h3>
              <p className="text-text-secondary mb-4">Available Monday - Saturday, 9 AM - 6 PM IST</p>
              <p className="text-accent-gold">+91 98765 43210</p>
              <p className="text-accent-gold">+91 98765 43211</p>
            </div>

            <div className="bg-bg-card border-2 border-border rounded-2xl p-6 hover:border-accent-gold transition">
              <div className="mb-4"><MessageSquare className="w-12 h-12 text-accent-gold" /></div>
              <h3 className="text-2xl font-bold mb-2">WhatsApp</h3>
              <p className="text-text-secondary mb-4">Quick support via WhatsApp</p>
              <p className="text-accent-gold">+91 98765 43210</p>
            </div>
          </div>

          <div className="bg-bg-card border-2 border-border rounded-2xl p-8">
            <div className="text-center mb-6">
              <div className="flex justify-center mb-4"><Send className="w-12 h-12 text-accent-gold" /></div>
              <h3 className="text-2xl font-bold">Send Message</h3>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Success/Error Messages */}
              {success && (
                <div className="bg-green-500/10 border border-green-500/50 rounded-2xl p-4 text-green-400 text-center font-bold">
                  Message sent successfully! We will get back to you soon.
                </div>
              )}
              {error && (
                <div className="bg-red-500/10 border border-red-500/50 rounded-2xl p-4 text-red-500 text-center font-bold">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-sm font-semibold mb-2">Name <span className="relative -top-1 ">*</span></label>
                <input
                  type="text"
                  placeholder="Your name"
                  value={formData.name}
                  onChange={(e) => handleFieldChange('name', e.target.value)}
                  maxLength={50}
                  className={`w-full bg-bg-secondary border rounded-lg px-4 py-3 focus:outline-none transition ${
                    fieldErrors.name 
                    ? 'border-red-500 focus:border-red-500' 
                    : 'border-border focus:border-accent-gold'
                  }`}
              
                />
                {/* {fieldErrors.name && (
                  <p className="text-red-500 text-sm mt-1">Name is required</p>
                )} */}
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Email <span className="relative -top-1 ">*</span></label>
                <input
                  type="email"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={(e) => handleFieldChange('email', e.target.value)}
                  maxLength={60}
                  className={`w-full bg-bg-secondary border rounded-lg px-4 py-3 focus:outline-none transition ${
                    fieldErrors.email 
                    ? 'border-red-500 focus:border-red-500' 
                    : 'border-border focus:border-accent-gold'
                  }`}
              
                />
                {/* {fieldErrors.email && (
                  <p className="text-red-500 text-sm mt-1">Email is required</p>
                )} */}
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Mobile Number <span className="relative -top-1 ">*</span></label>
                <input
                  type="tel"
                  placeholder="10-digit mobile number"
                  value={formData.mobileNumber}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '');
                    if (val.length <= 10) {
                      handleFieldChange('mobileNumber', val);
                    }
                  }}
                  className={`w-full bg-bg-secondary border rounded-lg px-4 py-3 focus:outline-none transition ${
                    fieldErrors.mobileNumber || mobileError
                    ? 'border-red-500 focus:border-red-500' 
                    : 'border-border focus:border-accent-gold'
                  }`}
               
                  maxLength={10}
                  pattern="[0-9]{10}"
                />
                {/* {(fieldErrors.mobileNumber || mobileError) && (
                  <p className="text-red-500 text-sm mt-1">
                    {fieldErrors.mobileNumber ? 'Mobile number is required' : mobileError}
                  </p>
                )} */}
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Subject <span className="relative -top-1 ">*</span></label>
                <input
                  type="text"
                  placeholder="What's this about?"
                  value={formData.subject}
                  onChange={(e) => handleFieldChange('subject', e.target.value)}
                  maxLength={200}
                  className={`w-full bg-bg-secondary border rounded-lg px-4 py-3 focus:outline-none transition ${
                    fieldErrors.subject 
                    ? 'border-red-500 focus:border-red-500' 
                    : 'border-border focus:border-accent-gold'
                  }`}
             
                />
                {/* {fieldErrors.subject && (
                  <p className="text-red-500 text-sm mt-1">Subject is required</p>
                )} */}
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Message</label>
                <textarea
                  rows={5}
                  placeholder="Your message..."
                  value={formData.message}
                  onChange={(e) => handleFieldChange('message', e.target.value)}
                  maxLength={500}
                  className={`w-full bg-bg-secondary border rounded-lg px-4 py-3 focus:outline-none transition resize-none ${
                    fieldErrors.message 
                    ? 'border-red-500 focus:border-red-500' 
                    : 'border-border focus:border-accent-gold'
                  }`}
                
                />
               
              </div>

              <button
                type="submit"
                disabled={loading}
                className="
                  w-full group relative flex items-center justify-center gap-3
                  bg-accent-gold text-bg-primary
                  py-5 rounded-2xl font-black text-sm uppercase tracking-[0.2em]
                  shadow-xl shadow-accent-gold/20
                  transition-all duration-300 ease-out
                  hover:shadow-2xl hover:shadow-accent-gold/40
                  hover:-translate-y-0.5
                  hover:bg-accent-gold/90
                  active:scale-[0.98]
                  disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Send Message
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}