'use client'

import { useState, useEffect, useCallback } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Clock, Image as ImageIcon, ChevronLeft, ChevronRight } from 'lucide-react'
import { motion } from 'framer-motion'
import { NewsItem } from '@/types'
import { getFullImageUrl } from '@/lib/utils'
import ApiService from '@/services/ApiService'

export default function News() {
  const [, setNewsItems] = useState<NewsItem[]>([])
  const [news, setNews] = useState<NewsItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isHovered, setIsHovered] = useState(false)

  // Responsive items per page - fixed to show exact number per row
  const [itemsPerPage, setItemsPerPage] = useState(1);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) setItemsPerPage(3);
      else if (window.innerWidth >= 768) setItemsPerPage(2);
      else setItemsPerPage(1);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const data = await ApiService.getAllNews()

        // Filter only active and published news
        const publishedNews = data.filter((item: NewsItem) =>
          item.activeStatus && item.newsStatus === "PUBLISHED"
        )

        setNewsItems(publishedNews)
        setNews(publishedNews)
      } catch (err) {
        console.error('Error fetching news:', err)
        setError(err instanceof Error ? err.message : 'An error occurred')
      } finally {
        setLoading(false)
      }
    }

    fetchNews()
  }, [])

  // Calculate total slides
  const totalSlides = Math.max(1, Math.ceil(news.length / itemsPerPage));

  // Navigation handlers - prevent going beyond bounds
  const handleNext = useCallback(() => {
    setCurrentIndex((prev) => {
      if (prev >= totalSlides - 1) return prev;
      return prev + 1;
    });
  }, [totalSlides]);

  const handlePrev = useCallback(() => {
    setCurrentIndex((prev) => {
      if (prev <= 0) return prev;
      return prev - 1;
    });
  }, []);

  // Auto-play logic
  useEffect(() => {
    if (news.length <= itemsPerPage || isHovered) return;

    const interval = setInterval(() => {
      handleNext();
    }, 4000);

    return () => clearInterval(interval);
  }, [news, itemsPerPage, isHovered, handleNext]);

  // Calculate if arrows should be shown
  const showPrevArrow = currentIndex > 0;
  const showNextArrow = currentIndex < totalSlides - 1 && news.length > itemsPerPage;

  // Calculate the exact transform for perfect 3-card alignment
  const getTransformValue = () => {
    if (itemsPerPage === 1) {
      return `-${currentIndex * 100}%`;
    }
    // For multiple items per page, calculate based on exact percentage
    const percentage = (currentIndex * 100) / itemsPerPage;
    return `-${percentage}%`;
  };

  if (loading) {
    return (
      <section id="news" className="py-20 bg-[#05161A]">
        <div className="w-[90%] max-w-[1800px] mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-sm text-accent-gold uppercase tracking-[4px] mb-2 font-bold">Market Insights</div>
            <h2 className="font-cinzel text-5xl font-bold mb-6 text-white">
              Latest <span className="text-accent-gold">News</span>
            </h2>
            <div className="h-4 w-64 bg-white/10 rounded mx-auto mb-4 animate-pulse" />
          </div>

          <div className="flex justify-center gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="w-full md:w-[calc((100%-32px)/2)] lg:w-[calc((100%-64px)/3)] bg-bg-card border-2 border-border rounded-2xl p-6">
                <div className="h-48 bg-white/10 rounded-lg mb-4 animate-pulse" />
                <div className="h-4 w-32 bg-white/10 rounded mb-4 animate-pulse" />
                <div className="h-6 w-full bg-white/10 rounded mb-3 animate-pulse" />
                <div className="h-12 w-full bg-white/10 rounded mb-4 animate-pulse" />
                <div className="h-4 w-48 bg-white/10 rounded animate-pulse" />
              </div>
            ))}
          </div>
        </div>
      </section>
    )
  }

  if (error) {
    return (
      <section id="news" className="py-20 bg-[#05161A]">
        <div className="w-[90%] max-w-[1800px] mx-auto px-6 text-center">
          <p className="text-red-400">Error loading news: {error}</p>
        </div>
      </section>
    )
  }

  const formatStatus = (status?: string) => {
    if (!status) return ''
    return status.toLowerCase().replace(/^\w/, c => c.toUpperCase())
  }

  return (
    <section
      id="news"
      className="py-20 bg-[#05161A] relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="w-[90%] max-w-[1800px] mx-auto px-6">
        <div className="text-center mb-12">
          <div className="text-sm text-accent-gold uppercase tracking-[4px] mb-2 font-bold">Market Insights</div>
          <h2 className="font-cinzel text-5xl font-bold mb-6 text-white">
            Latest <span className="text-accent-gold">News</span>
          </h2>
          <p className="text-text-secondary text-lg max-w-[700px] mx-auto">
            Real-time updates on market trends, indicators, and trading strategies
          </p>
        </div>

        {news.length === 0 ? (
          <div className="text-center text-text-secondary py-20 bg-white/5 rounded-3xl border border-white/10">
            <div className="text-2xl font-cinzel mb-2">No News Available</div>
            <p>Check back later for the latest market insights.</p>
          </div>
        ) : (
          <div className="relative group/slider">
            {/* Previous Arrow - Only show when not at start */}
            {showPrevArrow && (
              <button
                onClick={handlePrev}
                className="absolute left-[-20px] lg:left-[-40px] top-1/2 -translate-y-1/2 z-30 bg-white/5 hover:bg-accent-gold border border-white/10 hover:border-accent-gold p-5 rounded-full backdrop-blur-xl flex items-center justify-center shadow-2xl transition-all duration-500 hover:scale-110 active:scale-95 group-hover/slider:opacity-100 opacity-0 group-hover/slider:translate-x-0 -translate-x-4"
                aria-label="Previous news"
              >
                <ChevronLeft className="w-6 h-6 text-white group-hover:text-bg-primary" />
              </button>
            )}

            {/* Next Arrow - Only show when not at end */}
            {showNextArrow && (
              <button
                onClick={handleNext}
                className="absolute right-[-20px] lg:right-[-40px] top-1/2 -translate-y-1/2 z-30 bg-white/5 hover:bg-accent-gold border border-white/10 hover:border-accent-gold p-5 rounded-full backdrop-blur-xl flex items-center justify-center shadow-2xl transition-all duration-500 hover:scale-110 active:scale-95 group-hover/slider:opacity-100 opacity-0 group-hover/slider:translate-x-0 translate-x-4"
                aria-label="Next news"
              >
                <ChevronRight className="w-6 h-6 text-white group-hover:text-bg-primary" />
              </button>
            )}

            <div className="overflow-hidden py-10 px-4">
              <motion.div
                className="flex gap-8"
                animate={{
                  x: getTransformValue()
                }}
                transition={{
                  type: "spring",
                  stiffness: 200,
                  damping: 25,
                  bounce: 0.1
                }}
              >
                {news.map((item) => (
                  <div
                    key={item.id}
                    className="flex-shrink-0 w-full md:w-[calc((100%-32px)/2)] lg:w-[calc((100%-70px)/3)]"
                  >
                    <Link
                      href={`/news/${item.id}`}
                      className="block h-full"
                    >
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        viewport={{ once: true }}
                        className="bg-bg-card border-2 border-border rounded-2xl hover:border-accent-gold transition-all duration-300 group cursor-pointer h-full flex flex-col shadow-[0_20px_50px_rgba(0,0,0,0.3)] hover:shadow-[0_0_40px_rgba(212,175,55,0.1)]"
                      >
                        {/* Image Section - Fixed Height */}
                        {item.imageUrl && item.imageUrl !== "string" ? (
                          <div className="relative h-64 w-full overflow-hidden">
                            {item.imageUrl && item.imageUrl !== "string" ? (
                              <Image
                                src={getFullImageUrl(item.imageUrl)}
                                alt={item.title}
                                fill
                                className="object-cover transition-transform duration-700 group-hover:scale-110"
                                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                              />
                            ) : (
                              <div className="w-full h-full bg-gradient-to-br from-[#0C2D2A] via-[#05161A] to-[#0A1F22] flex items-center justify-center">
                                <div className="relative">
                                  <div className="absolute inset-0 bg-accent-gold/20 blur-xl rounded-full" />
                                  <ImageIcon className="w-16 h-16 text-accent-gold/60 relative z-10" />
                                </div>
                              </div>
                            )}


                            {/* Gradient Overlays */}
                            <div className="absolute inset-0 bg-gradient-to-t from-[#051113]/90 via-[#051113]/40 to-transparent" />
                            <div className="absolute inset-0 bg-gradient-to-r from-accent-gold/5 via-transparent to-accent-gold/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                            {/* Hover Overlay */}
                            <div className="absolute inset-0 bg-accent-gold/0 group-hover:bg-accent-gold/5 transition-all duration-500 flex items-center justify-center">
                              <div className="translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                                <div className="bg-black/40 backdrop-blur-md p-3 rounded-2xl border border-white/20">

                                </div>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="h-48 w-full mb-4 bg-gradient-to-br from-[#0C2D2A] to-[#05161A] rounded-lg flex items-center justify-center border border-border flex-shrink-0">
                            <ImageIcon className="w-12 h-12 text-text-secondary/50" />
                          </div>
                        )}

                        <div className=" p-6">

                          {/* Category and Status - Fixed Height */}
                          <div className="flex items-center justify-between mb-4 flex-shrink-0 min-h-[24px]">
                            <span className="text-sm text-accent-gold font-semibold truncate">
                              {item.newsCategoryName || 'News'}
                            </span>
                          </div>

                          {/* Title - Fixed Height with consistent line height */}
                          <h3 className="text-xl font-bold mb-3 text-white group-hover:text-accent-gold transition line-clamp-2 flex-shrink-0 leading-tight">
                            {item.title}
                          </h3>

                          {/* Description - Fixed Height with consistent line height */}
                          <p className="text-text-secondary mb-4 line-clamp-3 flex-shrink-0  leading-relaxed">
                            {item.shortDescription || item.description}
                          </p>

                          {/* Read More - Always at bottom with fixed height */}
                          <div className="flex items-center justify-between text-sm text-text-secondary mt-auto pt-4 border-t border-border/50 flex-shrink-0">
                            <span className="flex items-center gap-1 text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded-full whitespace-nowrap">
                              <Clock className="w-3 h-3 flex-shrink-0" />
                              {formatStatus(item.newsStatus)}
                            </span>
                            <span className="text-accent-gold group-hover:translate-x-1 transition whitespace-nowrap">
                              Read More →
                            </span>
                          </div>

                        </div>
                      </motion.div>
                    </Link>
                  </div>
                ))}
              </motion.div>
            </div>

            {/* Pagination Indicators */}
            {totalSlides > 1 && (
              <div className="flex justify-center items-center gap-3 mt-12">
                {Array.from({ length: totalSlides }).map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentIndex(i)}
                    className={`transition-all duration-500 ease-out rounded-full ${currentIndex === i
                        ? 'bg-accent-gold w-10 h-1.5'
                        : 'bg-white/10 hover:bg-white/30 w-3 h-1.5 hover:w-5'
                      }`}
                    aria-label={`Go to slide ${i + 1}`}
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  )
}