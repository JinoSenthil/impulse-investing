'use client'

import { useSelector } from 'react-redux'
import { RootState } from '@/lib/store'
import {
  BookOpen,
  CheckCircle2,
  BarChart3,
  Flame,
  GraduationCap,
  Trophy,
  Search,
  Bell,
  Star,
  Clock,
  FileText,
  Zap,
  User
} from 'lucide-react'

export default function DashboardContent() {
  const { user } = useSelector((state: RootState) => state.auth)

  const stats = [
    { icon: <BookOpen className="w-8 h-8 text-accent-gold" />, value: '12', label: 'Courses Enrolled', trend: '↗ +2' },
    { icon: <CheckCircle2 className="w-8 h-8 text-accent-gold" />, value: '65%', label: 'Avg. Completion', trend: '↗ +15%' },
    { icon: <BarChart3 className="w-8 h-8 text-accent-gold" />, value: '8', label: 'Active Indicators', trend: '↗ +1' },
    { icon: <Flame className="w-8 h-8 text-accent-gold" />, value: '156', label: 'Day Streak', trend: '↗ 7 Days' },
  ]

  const courses = [
    {
      icon: <BarChart3 className="w-8 h-8 text-accent-gold" />,
      title: 'Technical Analysis Fundamentals',
      duration: '4 Weeks',
      lesson: '12 of 18',
      progress: 65
    },
    {
      icon: <Zap className="w-8 h-8 text-accent-gold" />,
      title: 'Intraday Special Tricks',
      duration: '6 Weeks',
      lesson: '4 of 15',
      progress: 27
    }
  ]

  const activities = [
    { icon: <GraduationCap className="w-6 h-6 text-accent-gold" />, title: 'Completed Lesson', time: '2 hours ago' },
    { icon: <BarChart3 className="w-6 h-6 text-accent-gold" />, title: 'Indicator Signal', time: '5 hours ago' },
    { icon: <Trophy className="w-6 h-6 text-accent-gold" />, title: 'Achievement Unlocked', time: '8 hours ago' },
  ]

  return (
    <main className="p-4 md:p-8 w-full">
      {/* Top Bar */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div className="flex items-center gap-3">
          <h1 className="font-cinzel text-2xl md:text-3xl lg:text-4xl font-bold">
            Welcome back, {user?.firstName || 'User'}
          </h1>
          <User className="w-6 h-6 md:w-8 h-8 text-accent-gold" />
        </div>

        <div className="flex gap-3 md:gap-4 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
          <button className="flex-shrink-0 w-10 h-10 md:w-12 md:h-12 bg-bg-card border border-border rounded-xl flex items-center justify-center hover:border-accent-gold transition">
            <Search className="w-5 h-5 text-text-secondary" />
          </button>

          <button className="flex-shrink-0 w-10 h-10 md:w-12 md:h-12 bg-bg-card border border-border rounded-xl flex items-center justify-center hover:border-accent-gold transition relative">
            <Bell className="w-5 h-5 text-text-secondary" />
          </button>

          <button className="flex-shrink-0 w-10 h-10 md:w-12 md:h-12 bg-bg-card border border-border rounded-xl flex items-center justify-center hover:border-accent-gold transition">
            <Star className="w-5 h-5 text-text-secondary" />
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="bg-bg-card border-2 border-border rounded-2xl p-5 md:p-7 hover:border-accent-gold transition"
          >
            <div className="flex justify-between items-start mb-4">
              <div>{stat.icon}</div>
              <div className="text-accent-green text-sm font-semibold">{stat.trend}</div>
            </div>
            <div className="text-3xl md:text-4xl font-bold mb-2">{stat.value}</div>
            <div className="text-text-secondary text-sm">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Dashboard Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 md:gap-8">
        {/* Continue Learning */}
        <div className="bg-bg-card border-2 border-border rounded-2xl p-5 md:p-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl md:text-2xl font-bold">Continue Learning</h2>
            <a href="#" className="text-accent-gold hover:underline text-sm">View All →</a>
          </div>

          <div className="space-y-6">
            {courses.map((course, index) => (
              <div key={index} className="flex flex-col sm:flex-row gap-4">
                <div className="w-14 h-14 md:w-16 md:h-16 bg-bg-secondary rounded-xl flex items-center justify-center flex-shrink-0">
                  {course.icon}
                </div>

                <div className="flex-1">
                  <div className="font-bold mb-1 md:mb-2">{course.title}</div>

                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs md:text-sm text-text-secondary mb-3">
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" /> {course.duration}
                    </span>
                    <span className="flex items-center gap-1">
                      <FileText className="w-4 h-4" /> Lesson {course.lesson}
                    </span>
                  </div>

                  <div className="w-full bg-bg-secondary rounded-full h-2 mb-2">
                    <div
                      className="bg-accent-gold rounded-full h-2 transition-all"
                      style={{ width: `${course.progress}%` }}
                    />
                  </div>

                  <div className="text-xs text-text-secondary">{course.progress}% Complete</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-bg-card border-2 border-border rounded-2xl p-5 md:p-8">
          <h2 className="text-xl md:text-2xl font-bold mb-6">Recent Activity</h2>

          <div className="space-y-4">
            {activities.map((activity, index) => (
              <div key={index} className="flex items-start gap-4">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-bg-secondary rounded-xl flex items-center justify-center flex-shrink-0">
                  {activity.icon}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm md:text-base mb-1 truncate">
                    {activity.title}
                  </div>
                  <div className="text-[10px] md:text-xs text-text-secondary">
                    {activity.time}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
