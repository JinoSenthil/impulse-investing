'use client';

import { useState, useEffect, useCallback } from 'react'
import Image from 'next/image'
import Link from 'next/link'

import { Clock, ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react'
import { motion } from 'framer-motion'
import ApiService from '@/services/ApiService'
import { Course } from '@/types'
import { getFullImageUrl } from '@/lib/utils'

// Helper to extract YouTube ID from various URL formats


export default function Courses() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);



  // Responsive items per page
  const [itemsPerPage, setItemsPerPage] = useState(1);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) setItemsPerPage(3);
      else if (window.innerWidth >= 768) setItemsPerPage(2);
      else setItemsPerPage(1);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const data = await ApiService.getAllCourses();
        const activeCourses = data.filter(c => c.activeStatus);
        setCourses(activeCourses);
      } catch (err) {
        console.error('Failed to fetch courses:', err);
        setError('Failed to load courses. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    fetchCourses();
  }, []);

  // Auto-scroll logic
  const handleNext = useCallback(() => {
    setCurrentIndex((prev) =>
      prev >= courses.length - itemsPerPage ? 0 : prev + 1
    );
  }, [courses.length, itemsPerPage]);

  useEffect(() => {
    if (courses.length <= itemsPerPage || isHovered) return;

    const interval = setInterval(() => {
      handleNext();
    }, 4500);

    return () => clearInterval(interval);
  }, [courses, itemsPerPage, isHovered, currentIndex, handleNext]);

  const handlePrev = () => {
    setCurrentIndex((prev) =>
      prev === 0 ? Math.max(0, courses.length - itemsPerPage) : prev - 1
    );
  };

  if (loading) {
    return (
      <section id="courses" className="py-20 bg-[#020C0E]">
        <div className="w-[90%] max-w-[1800px] mx-auto text-center">
          <h2 className="text-white text-2xl font-cinzel animate-pulse">Loading Courses...</h2>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section id="courses" className="py-20 bg-[#020C0E]">
        <div className="w-[90%] max-w-[1800px] mx-auto text-center">
          <h2 className="text-red-500 text-xl font-cinzel">{error}</h2>
        </div>
      </section>
    );
  }

  return (
    <section
      id="courses"
      className="py-24 bg-[#020C0E] overflow-hidden relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Decorative Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-[20%] right-[-10%] w-[50%] h-[50%] bg-accent-gold/10 blur-[150px] rounded-full" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-accent-gold/5 blur-[120px] rounded-full" />
      </div>

      <div className="w-[90%] max-w-[1800px] mx-auto text-center px-6 relative z-10">
        <div className="text-center mb-20 px-4">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-sm text-accent-gold uppercase tracking-[5px] mb-4 font-bold"
          >
            Expert Education
          </motion.div>
          <h2 className="font-cinzel text-4xl md:text-6xl font-black mb-8 text-white tracking-tight">
            Trading <span className="text-accent-gold">Courses</span>
          </h2>
          <p className="text-text-secondary text-base md:text-xl max-w-[700px] mx-auto leading-relaxed">
            Comprehensive programs designed by professional traders to elevate your skills to an institutional level.
          </p>
        </div>

        {courses.length === 0 ? (
          <div className="text-center text-text-secondary text-xl py-20 bg-white/5 rounded-3xl border border-white/10 glass-panel">
            <div className="text-2xl font-cinzel mb-2">Coming Soon</div>
            <p>Our educational curriculum is being curated for excellence.</p>
          </div>
        ) : (
          <div className="relative group/slider">
            {/* Navigation Arrows - Premium Glass Style */}
            <button
              onClick={handlePrev}
              className="absolute left-[-20px] lg:left-[-40px] top-1/2 -translate-y-1/2 z-30 bg-white/5 hover:bg-accent-gold border border-white/10 hover:border-accent-gold p-5 rounded-full backdrop-blur-xl flex items-center justify-center shadow-2xl transition-all duration-500 hover:scale-110 active:scale-95 group-hover/slider:opacity-100 opacity-0 group-hover/slider:translate-x-0 -translate-x-4"
              aria-label="Previous course"
            >
              <ChevronLeft className="w-6 h-6 text-white group-hover:text-bg-primary" />
            </button>

            <button
              onClick={handleNext}
              className="absolute right-[-20px] lg:right-[-40px] top-1/2 -translate-y-1/2 z-30 bg-white/5 hover:bg-accent-gold border border-white/10 hover:border-accent-gold p-5 rounded-full backdrop-blur-xl flex items-center justify-center shadow-2xl transition-all duration-500 hover:scale-110 active:scale-95 group-hover/slider:opacity-100 opacity-0 group-hover/slider:translate-x-0 translate-x-4"
              aria-label="Next course"
            >
              <ChevronRight className="w-6 h-6 text-white group-hover:text-bg-primary" />
            </button>

            <div className="overflow-hidden py-10 px-4">
              <motion.div
                className="flex gap-8"
                animate={{
                  x: `calc(-${currentIndex * (100 / itemsPerPage)}% - ${currentIndex * (itemsPerPage > 1 ? 32 : 0)}px)`
                }}
                transition={{ type: "spring", stiffness: 200, damping: 25 }}
              >
                {courses.map((course) => {
                  const imageUrl = getFullImageUrl(course.coverImage);
                  const hasThumbnail = !!imageUrl && course.coverImage !== 'string';

                  return (
                    <div
                      key={course.id}
                      className="flex-shrink-0 w-full md:w-[calc((100%-32px)/2)] lg:w-[calc((100%-64px)/3)] bg-[#05161A] border border-accent-gold/20 rounded-[40px] p-8 relative group hover:border-accent-gold/60 transition-all duration-500 shadow-[0_20px_50px_rgba(0,0,0,0.4)] hover:shadow-[0_0_40px_rgba(212,175,55,0.15)] flex flex-col items-start text-left overflow-hidden"
                    >
                      {/* Shine effect on hover */}
                      <div className="absolute inset-0 bg-gradient-to-tr from-accent-gold/0 via-accent-gold/5 to-accent-gold/0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />

<div className="mb-8 rounded-[24px] overflow-hidden border border-white/10 shadow-xl relative group-hover:border-accent-gold/40 transition-all duration-500 h-[200px] w-full z-10">
                        <Image
                          src={hasThumbnail ? imageUrl : "/noimage.webp"}
                          alt={course.title}
                          fill
                          className={`object-cover transition-transform duration-700 group-hover:scale-110 ${!hasThumbnail ? 'opacity-50 grayscale' : ''}`}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                      </div>

                      {/* Title & Description */}
                      <h3 className="font-cinzel text-2xl md:text-3xl font-bold mb-4 text-white group-hover:text-accent-gold transition-colors line-clamp-2 min-h-[4rem] relative z-10">
                        {course.title}
                      </h3>
                      <div className="text-text-secondary text-lg mb-8 leading-relaxed max-w-[95%] line-clamp-3 h-[84px] overflow-hidden relative z-10" dangerouslySetInnerHTML={{ __html: course.shortDescription || course.description }} />

                      {/* Media Preview */}
                      

                      {/* Duration & Details */}
                      <div className="flex items-center gap-8 mb-10 text-text-secondary font-semibold z-10">
                        {course.duration && (
                          <div className="flex items-center gap-2.5 px-4 py-2 bg-white/5 rounded-full border border-white/10 backdrop-blur-md">
                            <Clock className="w-5 h-5 text-accent-gold" />
                            <span className="text-sm">{course.duration}</span>
                          </div>
                        )}
                      </div>

                      {/* View Details Button - Shimmer Style */}
                      <Link
                        href={`/courses/${course.id}`} 
                        className="w-full mt-auto bg-gradient-to-r from-accent-gold via-[#e5c158] to-[#c5a059] text-bg-primary py-4.5 rounded-2xl font-black text-base flex items-center justify-center gap-2 hover:brightness-110 transition-all duration-300 shadow-xl shadow-accent-gold/15 active:scale-95 relative overflow-hidden group/btn"
                      >
                        <span className="relative z-10 flex items-center gap-2 p-4">
                          View Details <ArrowRight className="w-5 h-5 group-hover/btn:translate-x-1 transition-transform" />
                        </span>
                        {/* Shimmer Animation */}
                        <div className="absolute top-0 -left-[100%] w-full h-full bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-[-20deg] group-hover/btn:animate-[shimmer_2s_infinite]" />
                      </Link>
                    </div>
                  )
                })}
              </motion.div>
            </div>

            {/* Pagination Indicators - Professional Style */}
            <div className="flex justify-center items-center gap-3 mt-12">
              {Array.from({ length: Math.max(0, courses.length - itemsPerPage + 1) }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentIndex(i)}
                  className={`transition-all duration-500 ease-out rounded-full ${currentIndex === i
                    ? 'bg-accent-gold w-10 h-1.5'
                    : 'bg-white/10 hover:bg-white/30 w-3 h-1.5 hover:w-5'
                    }`}
                  aria-label={`Go to slide ${i + 1}`}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Global CSS for Shimmer Animation */}
      <style jsx global>{`
        @keyframes shimmer {
          100% {
            left: 200%;
          }
        }
      `}</style>
    </section>
  )
}
