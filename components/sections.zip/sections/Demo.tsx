'use client'

import { useState } from 'react'
import Image from 'next/image'
import {
  MessageCircle,
  User,
  Phone,
  MapPin,
  CheckCircle2,
  Rocket
} from 'lucide-react'

import { useSelector } from 'react-redux'
import { RootState } from '@/lib/store'
import { Loader2 } from 'lucide-react'
import { useEffect } from 'react'

export default function Demo() {
  const { user } = useSelector((state: RootState) => state.auth)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    location: '',
    experience: '',
  })

  const [fieldErrors, setFieldErrors] = useState({
    name: false,
    phone: false,
    location: false,
    experience: false,
  })

  const [phoneError, setPhoneError] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        name: `${user.firstName} ${user.lastName}`.trim(),
        phone: user.phoneNumber || ''
      }))
    }
  }, [user])

  const validatePhone = (phone: string) => {
    if (phone.length === 0) return 'Phone number is required'
    if (phone.length !== 10) return 'Phone number must be 10 digits'
    if (!/^\d+$/.test(phone)) return 'Phone number must contain only digits'
    return null
  }

  const handleInputChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    
    // Clear field error when user starts typing
    if (fieldErrors[field]) {
      setFieldErrors(prev => ({ ...prev, [field]: false }))
    }
    
    // Special handling for phone validation
    if (field === 'phone') {
      const phoneError = validatePhone(value)
      setPhoneError(phoneError)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Reset all errors
    setError(null)
    setPhoneError(null)
    
    // Validate all fields
    const newFieldErrors = {
      name: !formData.name.trim(),
      phone: !formData.phone.trim(),
      location: !formData.location.trim(),
      experience: !formData.experience.trim(),
    }
    
    // Validate phone specifically
    const phoneValidationError = validatePhone(formData.phone)
    
    // Set all errors at once
    setFieldErrors(newFieldErrors)
    setPhoneError(phoneValidationError)
    
    // Check if there are any errors
    const hasFieldErrors = Object.values(newFieldErrors).some(error => error)
    const hasPhoneValidationError = phoneValidationError !== null
    
    if (hasFieldErrors || hasPhoneValidationError) {
      // If there are errors, don't submit
      console.log('Please fill in all required fields correctly.')
      return
    }
    
    // If no errors, proceed with submission
    setLoading(true)
    setSuccess(false)

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      // On success
      setSuccess(true)
      setFormData({ name: '', phone: '', location: '', experience: '' })
      setFieldErrors({ name: false, phone: false, location: false, experience: false })
      setPhoneError(null)
      setError(null)
      
    } catch {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <section
      id="demo"
      className="relative min-h-screen text-white px-8 py-24 overflow-hidden"
    >
      <div className="max-w-[1400px] mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-20">
          <span className="inline-block mb-6 px-6 py-2 rounded-full bg-[#22C55E]/10 border border-[#22C55E]/40 text-[#22C55E] text-xs font-black tracking-widest">
            LIMITED TIME OFFER
          </span>

          <h3 className="font-cinzel text-xl md:text-5xl font-black mb-6">
            BOOK YOUR
            <span className="font-cinzel text-[3rem] font-bold uppercase tracking-[3px] text-accent-green select-none drop-shadow-[0_0_15px_rgba(34,197,94,0.5)]">
              2-DAY FREE
            </span>
            INDICATOR DEMO
          </h3>

          <p className="text-gray-400 max-w-[700px] mx-auto text-lg">
            Experience the power of our premium trading indicators for 48 hours.
            Fill out the form below to get started!
          </p>
        </div>

        {/* Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center justify-center">
          {/* Form */}
          <div className="bg-[#0d1f0de6] border-2 border-emerald-500/40 rounded-3xl p-10 shadow-2xl backdrop-blur-xl">

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Name */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-black tracking-widest text-white">
                  <User className="w-5 h-5 text-[#22C55E]" />
                  Full Name 
                  <span className="relative -top-1"> *</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Full Name"
                    className={`w-full bg-[#001408] border-2 rounded-2xl px-5 py-4 focus:border-[#22C55E] outline-none transition placeholder-gray-400 ${fieldErrors.name ? 'border-red-500/50 focus:border-red-500' : 'border-[#22C55E]/30 focus:border-[#22C55E]'}`}
                    value={formData.name}
                    maxLength={50}
                    onChange={(e) =>
                      handleInputChange('name', e.target.value)
                    }
  
                  />
                </div>
                {/* {fieldErrors.name && <p className="text-red-500 text-xs font-bold">Name is required</p>} */}
              </div>

              {/* Phone */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-black tracking-widest text-white">
                  <Phone className="w-5 h-5 text-[#22C55E]" />
                  Phone Number
                  <span className="relative -top-1 "> *</span>
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    maxLength={10}
                    placeholder="10-digit mobile number"
                    className={`w-full bg-[#001408] border-2 rounded-2xl px-5 py-4 outline-none transition placeholder-gray-400 ${fieldErrors.phone || phoneError ? 'border-red-500/50 focus:border-red-500' : 'border-[#22C55E]/30 focus:border-[#22C55E]'}`}
                    value={formData.phone}
                    onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, '')
                      handleInputChange('phone', val)
                    }}
               
                  />
                </div>
                {/* {(fieldErrors.phone || phoneError) && (
                  <p className="text-red-500 text-xs font-bold">
                    {fieldErrors.phone ? 'Phone number is required' : phoneError}
                  </p>
                )} */}
              </div>

              {/* Location */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-black tracking-widest text-white">
                  <MapPin className="w-5 h-5 text-[#22C55E]" />
                  Location (City / State)
                 <span className="relative -top-1"> *</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="e.g. Mumbai, Maharashtra"
                    className={`w-full bg-[#001408] border-2 rounded-2xl px-5 py-4 focus:border-[#22C55E] outline-none transition placeholder-gray-400 ${fieldErrors.location ? 'border-red-500/50 focus:border-red-500' : 'border-[#22C55E]/30 focus:border-[#22C55E]'}`}
                    value={formData.location}
                    maxLength={50}
                    onChange={(e) =>
                      handleInputChange('location', e.target.value)
                    }
                  />
                </div>
                {/* {fieldErrors.location && <p className="text-red-500 text-xs font-bold">Location is required</p>} */}
              </div>

              {/* Trading Experience */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-black tracking-widest text-white">
                  <Rocket className="w-5 h-5 text-[#22C55E]" />
                  Trading Experience 
                  <span className="relative -top-1">*</span>
                </label>
                <div className="relative">
                  <textarea
                    rows={4}
                    placeholder="Beginner / Intermediate / Advanced — tell us briefly"
                    className={`w-full bg-[#001408] border-2 rounded-2xl px-5 py-4 focus:border-[#22C55E] outline-none transition resize-none placeholder-gray-400 ${fieldErrors.experience ? 'border-red-500/50 focus:border-red-500' : 'border-[#22C55E]/30 focus:border-[#22C55E]'}`}
                    value={formData.experience}
                    maxLength={300}
                    onChange={(e) =>
                      handleInputChange('experience', e.target.value)
                    }
                  />
                </div>
                {/* {fieldErrors.experience && <p className="text-red-500 text-xs font-bold">Trading experience is required</p>} */}
              </div>

              {error && <p className="text-red-500 text-xs font-bold">{error}</p>}
              {success && <p className="text-accent-green text-xs font-bold">Successfully booked! We will contact you soon.</p>}

              {/* Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-3 bg-[#22C55E] text-black py-5 rounded-2xl font-black text-sm hover:scale-[1.02] active:scale-95 disabled:opacity-50 disabled:hover:scale-100 transition shadow-[0_0_20px_rgba(34,197,94,0.3)]"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <MessageCircle className="w-5 h-5" />}
                {loading ? 'Processing...' : 'Book My Free Demo'}
              </button>
            </form>


            {/* Trust points */}
            <div className="mt-8 text-center text-[#6E7A84]">
              <span>We respect your privacy. No spam, ever.</span>
            </div>

          </div>

          {/* Image + Details */}
          <div className="space-y-8">
            <div className="relative rounded-3xl border-2 border-emerald-500/40 bg-gradient-to-b from-gray-900/60 to-black/80 p-6 shadow-2xl">
              <Image
                src="/course3.png"
                alt="Indicator Demo"
                width={800}
                height={600}
                className="rounded-2xl object-cover"
                priority
              />
            </div>

            {/* What You Get */}
            <div className="bg-[#0d1f0d]/50 border-2 border-emerald-500/40 rounded-3xl p-8 shadow-xl">
              <h4 className="text-xl font-black mb-6 text-[#22C55E]">
                What You Get in the Demo:
              </h4>

              <ul className="space-y-4 text-gray-300 text-sm font-semibold">
                {[
                  'Full access to Hulk Scalper V3 Indicator',
                  'Real-time buy/sell signals for 48 hours',
                  'Personal onboarding call with our expert',
                  'Access to exclusive Telegram community',
                  'No payment required - 100% Free trial',
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#22C55E] mt-0.5" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}