'use client';

import { useState, useEffect } from 'react';
import ApiService from '@/services/ApiService';
import { AboutData } from '@/types';

export default function About() {
  const [aboutData, setAboutData] = useState<AboutData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAboutData = async () => {
      try {
        const data = await ApiService.getAllAbout();
        // Use the first active about entry
        const activeAbout = data.find(item => item.activeStatus);
        if (activeAbout) {
          setAboutData(activeAbout);
        }
      } catch (err) {
        console.error('Failed to fetch about data:', err);
        setError('Failed to load about information.');
      } finally {
        setLoading(false);
      }
    };

    fetchAboutData();
  }, []);

  if (loading) {
    return (
      <section id="about" className="py-20 px-6 bg-[#020C0E]">
        <div className="w-[90%] max-w-[1800px] mx-auto text-center">
          <div className="text-accent-gold animate-pulse font-cinzel text-xl">
            Loading About Information...
          </div>
        </div>
      </section>
    );
  }

  // If no data is found, we can either hide the section or show nothing
  if (!aboutData && !error) return null;

  return (
    <section id="about" className="py-20 px-6 bg-[#020C0E]">
      <div className="w-[90%] max-w-[1800px] mx-auto">
        <div className="text-center mb-16">
          <div className="text-sm text-accent-gold uppercase tracking-[2px] mb-4">Our Story</div>
          <h2 className="font-cinzel text-5xl font-bold mb-6 text-white">
            About <span className="text-accent-gold">IMPULSE</span>
          </h2>
          <p className="text-text-secondary text-lg max-w-[600px] mx-auto">
            Empowering traders worldwide with cutting-edge tools and education
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <h3 className="text-3xl font-bold text-white">{aboutData?.title}</h3>
            <div
              className="text-text-secondary leading-relaxed space-y-4"
              dangerouslySetInnerHTML={{ __html: aboutData?.description || '' }}
            />
          </div>

          <div className="space-y-6">
            <div className="bg-bg-card border-2 border-border rounded-2xl p-6 hover:border-accent-gold transition">
              <h4 className="text-xl font-bold mb-3 text-white">Our Mission</h4>
              <p className="text-text-secondary">
                {aboutData?.ourMision}
              </p>
            </div>

            <div className="bg-bg-card border-2 border-border rounded-2xl p-6 hover:border-accent-gold transition">
              <h4 className="text-xl font-bold mb-3 text-white">Our Vision</h4>
              <p className="text-text-secondary">
                {aboutData?.ourVision}
              </p>
            </div>

            <div className="bg-bg-card border-2 border-border rounded-2xl p-6 hover:border-accent-gold transition">
              <h4 className="text-xl font-bold mb-3 text-white">Our Values</h4>
              <p className="text-text-secondary">
                {aboutData?.ourValues}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
